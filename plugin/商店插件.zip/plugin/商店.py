# Author: unknown
Description: unknown



# PLUGIN TYPE: def
shopGoodList = []
class shopGood():
    def __init__(self, nameShow, nameGive, priceBuy, priceSell, specialID = None):
        self.nameShow = nameShow
        self.nameGive = nameGive
        self.priceBuy = priceBuy
        self.priceSell = priceSell
        if specialID is None:
            self.specialID = -1
        else:
            self.specialID = specialID
        color("§e商店插件: 正在加载商品 §b%s" % self.nameShow, replace = True)
        shopGoodList.append(self)
    def buy(self, playername, number = None):
        if number is None:
            number = 1
        if number <= 0 or number >= 1025:
            tellrawText(playername, "§l§4ERROR§r", "§c商品数量不正确")
        else:
            if self.priceBuy <= -1:
                tellrawText(playername, "§l§6Ritle§aBlock§r", "§c此商品不能被购买")
            else:
                priceBuyTotal = float2int(self.priceBuy*number, way = 3)
                coinPlayer = getScore("coin", playername)
                if coinPlayer >= priceBuyTotal:
                    sendcmd("/scoreboard players remove %s coin %d" % (playername, priceBuyTotal))
                    if self.specialID == -1:
                        sendcmd("/give %s %s %d" % (playername, self.nameGive, number))
                    else:
                        sendcmd("/give %s %s %d %d" % (playername, self.nameGive, number, self.specialID))
                    tellrawText(playername, "§l§6Ritle§aBlock§r", "已购买 §l%s§r*§l%d§r, \n花费金币 §l%d§r, 剩余金币 §l%d§r." % (self.nameShow, number, priceBuyTotal, coinPlayer-priceBuyTotal))
                else:
                    tellrawText(playername, "§l§6Ritle§aBlock§r", "§c金币数量不足, 需要金币 §l%d§r§c, 你有金币 §l%d§r§c." % (priceBuyTotal, coinPlayer))
    def sell(self, playername, number = None):
        if number is None:
            number = 1
        if number <= 0 or number >= 1025:
            tellrawText(playername, "§l§4ERROR§r", "§c商品数量不正确")
        else:
            if self.priceSell <= -1:
                tellrawText(playername, "§l§6Ritle§aBlock§r", "§c此商品不能被卖出")
            else:
                priceSellTotal = float2int(self.priceSell*number, way = 2)
                itemPlayer = getItem(playername, self.nameGive, self.specialID)
                if itemPlayer >= number:
                    sendcmd("/clear %s %s %d %d" % (playername, self.nameGive, self.specialID, number))
                    sendcmd("/scoreboard players add %s coin %d" % (playername, priceSellTotal))
                    tellrawText(playername, "§l§6Ritle§aBlock§r", "已卖出 §l%s§r*§l%d§r, \n获得金币 §l%d§r, 剩余金币 §l%d§r." % (self.nameShow, number, priceSellTotal, getScore("coin", playername)))
                else:
                    tellrawText(playername, "§l§6Ritle§aBlock§r", "§c物品数量不足, 需要物品 §l%d§r§c, 你有物品 §l%d§r§c." % (number, itemPlayer))
    def list(self, playername, goodIndex):
        if self.priceBuy <= -1:
            if self.priceSell <= -1:
                tellrawText(playername, "§l§6Ritle§aBlock§r", "商品§e%d§r. %s, 购买价: %s, 卖出价: %s" % (goodIndex, self.nameShow, "不支持购买", "不支持卖出"))
            if self.priceSell >= 0:
                tellrawText(playername, "§l§6Ritle§aBlock§r", "商品§e%d§r. %s, 购买价: %s, 卖出价: %.2f" % (goodIndex, self.nameShow, "不支持购买", self.priceSell))
        if self.priceBuy >= 0:
            if self.priceSell <= -1:
                tellrawText(playername, "§l§6Ritle§aBlock§r", "商品§e%d§r. %s, 购买价: %f.2, 卖出价: %s" % (goodIndex, self.nameShow, self.priceBuy, "不支持卖出"))
            if self.priceSell >= 0:
                tellrawText(playername, "§l§6Ritle§aBlock§r", "商品§e%d§r. %s, 购买价: %.2f, 卖出价: %.2f" % (goodIndex, self.nameShow, self.priceBuy, self.priceSell))
shopGoodProfile = getStatus("shopPrice").replace("\r", "").split("\n")
if "获取失败" in shopGoodProfile:
    color("§4无法读取商品价格表, 文件位置: status\\shopPrice.txt")
if not faststart:
    time.sleep(1)
for i in shopGoodProfile:
    if i == "":
        continue
    if i[0] != "#" and len(i.split(" ")) == 4:
        shopGood(i.split(" ")[0], i.split(" ")[1], float(i.split(" ")[2]), float(i.split(" ")[3]))
        if not faststart:
            time.sleep(int(5000/len(shopGoodProfile))/1000)
    elif i[0] != "#" and len(i.split(" ")) == 5:
        shopGood(i.split(" ")[0], i.split(" ")[1], float(i.split(" ")[2]), float(i.split(" ")[3]), int(i.split(" ")[4]))
        if not faststart:
            time.sleep(int(5000/len(shopGoodProfile))/1000)



# PLUGIN TYPE: player message
if msg[0:5] == ".shop":
    if msg == ".shop help" or msg == ".shop help ":
        sendcmd("/tellraw "+playername+r""" {"rawtext":[{"text":"输入§e.shop list §r查询商品买卖价格表\n输入§e.shop buy <商品名> <数量> §r购买商品\n输入§e.shop sell <商品名> <数量> §r卖出商品"}]}""")
    elif msg == ".shop list" or msg == ".shop list ":
        goodIndex = 0
        for i in shopGoodList:
            goodIndex += 1
            i.list(playername, goodIndex)
    elif msg[0:10] == ".shop buy " and len(msg.split(" ")) == 4:
        numberBuy = int(msg.split(" ")[3])
        for i in shopGoodList:
            if msg.split(" ")[2] == i.nameShow:
                i.buy(playername, numberBuy)
                break
    elif msg[0:11] == ".shop sell " and len(msg.split(" ")) == 4:
        numberSell = int(msg.split(" ")[3])
        for i in shopGoodList:
            if msg.split(" ")[2] == i.nameShow:
                i.sell(playername, numberSell)
                break



# PLUGIN TYPE: player join
sendcmd("/scoreboard players add @a[name=%s] coin 0" % playername)


