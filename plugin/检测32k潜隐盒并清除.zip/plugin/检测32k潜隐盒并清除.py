# Author: unknown
Description: unknown



# PLUGIN TYPE: packet 56
if "Items" in jsonPkt["NBTData"]:
    shulkerBoxPos = "%d %d %d" % (jsonPkt["Position"][0], jsonPkt["Position"][1], jsonPkt["Position"][2])
    shulkerBoxItemList = jsonPkt["NBTData"]["Items"]
    has32k = False
    is32k = False
    enchMsg = "§c检测到坐标 §l%s§r§c 内潜影盒有不合法附魔, 已fill, 详细信息: " % shulkerBoxPos
    for i in shulkerBoxItemList:
        is32k = False
        enchItemMsg = "\n§c物品: §l%s§r§c" % i["Name"]
        if "tag" in i:
            if "ench" in i["tag"]:
                for j in i["tag"]["ench"]:
                    if j["lvl"] > 5:
                        has32k = True
                        is32k = True
                        # enchItemMsg += "\n  附魔id: §l%s§r§c, 附魔等级: §l%d§r§c" % (j["id"], j["lvl"])
        if is32k:
            enchMsg += enchItemMsg
    if has32k:
        sendcmd("/setblock %s air" % shulkerBoxPos)
        tellrawText("@a", "§l§4Warning§r", enchMsg)
        # 我放我服试试, 做好了
        # 先更新命令系统



