# Author: unknown
Description: unknown



# PLUGIN TYPE: player death
if msg == "death.attack.player" and killer:
    try:
        has32k = False
        enchMsg = "§c检测到玩家 §l%s§r§c 有不合法附魔, 已清包, 详细信息: " % killer
        for i in getMainhandItem(killer)["NBTData"]["ench"]:
            if i["lvl"] > 5:
                has32k = True
                enchMsg += "\n附魔id: §l%s§r§c, 附魔等级: §l%d§r§c" % (i["id"], i["lvl"])
        if has32k:
            sendcmd("/clear %s" % killer)
            tellrawText("@a", "§l§4Warning§r", enchMsg)
            ban(killer, 864000, "用32k打人", "命令系统")
    except Exception as err:
        print(err)



