from robot import *
from 跨维度传送 import *
# 作者: 7912, Pomelo.
# 描述: 传送点 (跨维度版).



# PLUGIN TYPE: def

HOME_MAX_NUM = 5 # 最大传送点数量

if os.path.isfile("./plugin/传送点.py"):
    os.remove("./plugin/传送点.py")
    color("§a已删除旧版 传送点.py, 正在重启", info = "§a 升级 ")
    exitChatbarMenu("已删除旧版传送点.py, 正在重启")

def translateDim(dimension):
    if dimension == 0:
        return "主世界"
    if dimension == 1:
        return "地狱"
    if dimension == 2:
        return "末地" 
    raise ValueError("维度只能是0, 1或2.")

# 这里是做转换的部分.
for player in os.listdir("player"):
    if os.path.isfile("./player/%s/home.txt" % player): # 如果有旧版记录文件.
        homeData = []
        homeList = getPlayerData("home", player, writeNew = "[]").split("\n")
        for home in homeList:
            if not home: # 排除空行
                continue
            homeName = home.split(", pos: ")[0]
            homePos = home.split(", pos: ")[1]
            homeData.append({
                "name": homeName,
                "dim": 0,
                "pos": homePos
            })
        setPlayerData("home_new", player, json.dumps(homeData, ensure_ascii = False, indent = 4))
        os.remove("./player/%s/home.txt" % player)


# PLUGIN TYPE: player message
# 之前写的代码太差了...需要全部重来 我好卡 这.. 重进..? 应该是网卡。 没事 好像不卡了
if msg == ".help":
    tellrawText(playername, text = ".home §o§7- 查看传送点插件帮助§r")
if msg == ".home":
    tellrawText(playername, text = """\
  .home tp <传送点名称> §o§7- 传送到传送点.§r
  .home add <传送点名称> §o§7- 在当前位置新建传送点.§r
  .home del <传送点名称> §o§7- 删除传送点.§r
  .home list §o§7- 列出传送点.§r""")


if msg.startswith(".home add "):
    homeName = msg.split(" ", 2)[2]
    if (len(homeName) < 1) or (len(homeName) > 6):
        tellrawText('@a[name="%s"]' % playername, "§l§4ERROR§r", "§c传送点名称应为 §l1~6§r§c 个字符.")
        raise PluginSkip("return")

    homeList = json.loads(getPlayerData("home_new", playername, writeNew = "[]"))
    if len(homeList) >= HOME_MAX_NUM:
        tellrawText('@a[name="%s"]' % playername, "§l§4ERROR§r", "§c传送点数量达到上限. (§l%d§r§c 个)." % HOME_MAX_NUM)
        raise PluginSkip("return")

    for home in homeList:
        if home["name"] == homeName:
            tellrawText('@a[name="%s"]' % playername, "§l§4ERROR§r", "§c传送点重名.")
            raise PluginSkip("return")

    playerPos = getPos('@a[name="%s"]' % playername)
    homeList.append({
        "name": homeName,
        "dim": playerPos["dimension"],
        "pos": "%s %s %s" % (playerPos["position"]["x"], playerPos["position"]["y"], playerPos["position"]["z"])
    })
    tellrawText('@a[name="%s"]' % playername, "§l传送点§r", "已设置传送点 §l%s§r [§l%s§r, (§l%s§r, §l%s§r, §l%s§r)]." % (homeName, translateDim(playerPos["dimension"]), playerPos["position"]["x"], playerPos["position"]["y"], playerPos["position"]["z"]))
    setPlayerData("home_new", playername, json.dumps(homeList, ensure_ascii = False, indent = 4))


if msg.startswith(".home del "):
    homeName = msg.split(" ", 2)[2]
    homeList = json.loads(getPlayerData("home_new", playername, writeNew = "[]"))
    for home in homeList:
        if home["name"] == homeName:
            homeList.remove(home)
            homeX, homeY, homeZ = home["pos"].split(" ", 2)
            setPlayerData("home_new", playername, json.dumps(homeList, ensure_ascii = False, indent = 4))
            tellrawText('@a[name="%s"]' % playername, "§l传送点§r", "已删除传送点 §l%s§r [§l%s§r, (§l%s§r, §l%s§r, §l%s§r)]." % (homeName, translateDim(home["dim"]), homeX, homeY, homeZ))
            raise PluginSkip("return")
    tellrawText('@a[name="%s"]' % playername, "§l§4ERROR§r", "§c未找到传送点.")


if msg.startswith(".home tp "):
    homeName = msg.split(" ", 2)[2]
    homeList = json.loads(getPlayerData("home_new", playername, writeNew = "[]"))
    for home in homeList:
        if home["name"] == homeName:
            homeX, homeY, homeZ = home["pos"].split(" ", 2)
            tp('@a[name="%s"]' % playername, x = homeX, y = homeY, z = homeZ, dimension = home["dim"])
            tellrawText('@a[name="%s"]' % playername, "§l传送点§r", "已传送到传送点 §l%s§r [§l%s§r, (§l%s§r, §l%s§r, §l%s§r)]." % (homeName, translateDim(home["dim"]), homeX, homeY, homeZ))
            raise PluginSkip("return")
    tellrawText('@a[name="%s"]' % playername, "§l§4ERROR§r", "§c未找到传送点.")

if msg == ".home list":
    homeList = json.loads(getPlayerData("home_new", playername, writeNew = "[]"))
    tellrawText(playername, "§l传送点§r", "传送点列表: ")
    for index, home in enumerate(homeList): # enumerate 函数是将列表前面加上序号, 这样就可以便捷显示序号了. 这里序号存在了 index 中.哦哦 明白了
        homeX, homeY, homeZ = home["pos"].split(" ", 2) 
        tellrawText(playername, text = """\
  %d. §l%s§r, [§l%s§r, (§l%s§r, §l%s§r, §l%s§r)].""" % (index+1, home["name"], translateDim(home["dim"]), homeX, homeY, homeZ))

# 好像.. 可以了..? 感觉比旧版的代码简洁多了. 去测试服试试..? 好