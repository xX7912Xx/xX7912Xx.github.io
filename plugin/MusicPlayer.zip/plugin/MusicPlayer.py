# Author: unknown
Description: unknown



# PLUGIN TYPE: def
# 创建数据文件夹.
if not os.path.isdir("plugin/data/MusicPlayer"):
    os.mkdir("plugin/data/MusicPlayer")

# 输出说明.
color("Music Player Plugin is loading.")
color("Author: SuperScript, 7912.")
color("This plugin uses a PyPi named bdx_work_shop by 2401PT.")
color("仅支持 §e.mid§r 格式的音乐, 不能播放mp3和wav")
color("请把 .mid 音乐文件放到 §eplugin/data/MusicPlayer/§r 文件夹中.")
if not faststart:
    countdown(3, "§e请阅读说明")

# 使用2401PT的bdx_work_shop库转换音乐文件为 /playsound 指令.
musicList = os.listdir("plugin/data/MusicPlayer/")
color("§e加载音乐文件...")
for i in musicList:
    try:
        if i.endswith(".mccmd"):
            continue
        if os.path.isfile("plugin/data/MusicPlayer/%s.mccmd" % i):
            continue
        color("§e正在转换音乐文件 %s 为 /playsound 指令" % i)
        midi_input = "plugin/data/MusicPlayer/%s" % i
        canvas = bdx_work_shop.canvas.Canvas()
        artist = bdx_work_shop.artists.cmd_midi_music.Artist(canvas=canvas, y=canvas.y+10)
        cmdYuanzu = artist.convert_music_to_mc_sound(
            midi_input,
            instrumentes_mapping=collections.defaultdict(lambda :[     # 所有通道都采用一样的处理方式
                    (30,None),                              # <30 不处理
                    (31,'bass'),                            # 30~54 bass
                    (126,'pling'),                            # 54~78 harp 钢琴
                    (127,'bell'),                           # 78~102 bell
                    (128,None)                              # 128< 不处理
                ])
        )
        with open("plugin/data/MusicPlayer/%s.mccmd" % i, "w", encoding = "utf-8") as file:
            file.write(str(cmdYuanzu[-1][0]) + "\n")
            for tip, instrument, note, vol in cmdYuanzu:
                if vol == 0:
                    color("Ignored volume 0 at %f" % tip)
                    continue
                file.write("{tip} /playsound note.{ins} @s ~ ~ ~ {vol} {note}\n".format(tip = tip, ins = instrument, vol = vol, note = note))
    except Exception as err:
        color("§4无法转换文件 %s, 原因: %s" % (i, str(err)))
        color("§c"+traceback.format_exc())
        exitChatbarMenu(delay = 60)


# 播放音乐的函数(使用命令系统社区版创建线程功能).
def playMusic(self):
    playername = self.data["playername"]
    musicName = self.data["musicName"]
    musicCmdList = self.data["musicCmdList"]
    lastTip = 0
    musicLength = second2minsec(float(musicCmdList.pop(0)))
    tellrawText(playername, "§lMusic Player§r", "开始播放: %s, 时长: %s" % (musicName, musicLength))
    musicStartTime = time.time()
    lastShowProcess = time.time() - 1
    for i in musicCmdList:
        if i:
            tip = float(i.split(" ", 1)[0])
            musicCmd = i.split(" ", 1)[1]
            delay = musicStartTime + tip
            tipFormat = second2minsec(tip)
            while time.time() < delay:
                time.sleep(0.001)
            sendcmd("/execute @a[name=%s] ~ ~ ~ %s" % (playername, musicCmd))
            if time.time() - lastShowProcess >= 1:
                lastShowProcess = time.time()
                sendcmd("/title @a[name=%s] actionbar 正在播放: %s\n%s / %s" % (playername, musicName, tipFormat, musicLength))



# PLUGIN TYPE: player message
# 帮助菜单.
if msg == ".help":
    tellrawText(playername, text = "输入§l.music§r查看音乐播放插件帮助")

# 详细帮助菜单.
elif msg == ".music" or msg == ".music ":
    tellrawText(playername, "§lMusic Player§r", "\n音乐播放插件  帮助菜单\n输入 §l.music list §r获取音乐列表\n输入 §l.music play <音乐名称> §r开始播放音乐(可模糊搜索)\n输入 §l.music stop §r停止播放音乐\n输入 §l.music playlist §r获取正在播放的音乐列表")

# 功能区.
elif msg.startswith(".music "):
    action = msg.split(" ")[1]

    # 播放音乐.
    if action == "play":
        musicName = msg.split(" ", 2)[2]
        for i in threadList[:]:
            if i.name == "musicPlay":
                if i.data["playername"] == playername:
                    tellrawText(playername, "§l§4ERROR§r", "§c你已经在播放音乐了, 无法播放新的.")
                    raise PluginSkip()
        musicList = os.listdir("plugin/data/MusicPlayer/")
        for i in musicList[:]:
            if not i.endswith(".mccmd"):
                musicList.remove(i)
        musicFind = []
        for i in musicList:
            if musicName in i:
                musicFind.append(i.replace(".mccmd", ""))
        if len(musicFind) == 0:
            tellrawText(playername, "§l§4ERROR§r", "§c未搜索到此音乐.")
            raise PluginSkip()
        if len(musicFind) >= 2:
            tellrawText(playername, "§l§4ERROR§r", "§c搜索到 §l%d§r§c 首音乐, 无法播放:" % len(musicFind))
            for i in range(len(musicFind)):
                tellrawText(playername, "§l§4ERROR§r", "§c§l%d§r§c. %s" % (i+1, musicFind[i]))
            raise PluginSkip()
        musicName = musicFind[0]
        musicCmdList = open("plugin/data/MusicPlayer/%s.mccmd" % musicName, "r", encoding = "utf-8").read().replace("\r", "").split("\n")
        # 使用命令系统社区版创建线程函数创建播放线程.
        createThread("musicPlay", {"playername": playername, "musicName": musicName, "musicCmdList": musicCmdList}, playMusic)

    # 显示音乐列表.
    elif action == "list":
        musicList = os.listdir("plugin/data/MusicPlayer/")
        for i in musicList[:]:
            if not i.endswith(".mccmd"):
                musicList.remove(i)
        for i in range(len(musicList)):
            tellrawText(playername, "§lMusic Player§r", "§l%d§r. %s" % (i+1, musicList[i].replace(".mccmd", "")))
    
    # 停止播放音乐.
    elif action == "stop":
        # 遍历命令系统社区版启动的线程.
        for i in threadList[:]:
            if i.name == "musicPlay":
                if i.data["playername"] == playername:
                    i.stop() # 停止线程
                    tellrawText(playername, "§lMusic Player§r", "已停止播放.")

    # 显示正在播放的音乐列表.
    elif action == "playlist":
        playIndex = 0
        for i in threadList[:]:
            if i.name == "musicPlay":
                playIndex += 1
                tellrawText(playername, "§lMusic Player§r", "§l%d§r. %s 正在播放 %s" % (playIndex, i.data["playername"], i.data["musicName"]))
        if playIndex == 0:
            tellrawText(playername, "§lMusic Player§r", "暂无音乐正在播放.")
