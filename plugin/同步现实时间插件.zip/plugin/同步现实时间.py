# Author: unknown
Description: unknown



# PLUGIN TYPE: init
sendcmd("/gamerule dodaylightcycle false")



# PLUGIN TYPE: repeat 1s
timeReallife = datetime.datetime.now()
timeReallifeH = timeReallife.hour
timeReallifeM = timeReallife.minute
timeReallifeS = timeReallife.second
timeReallifeSall = timeReallifeH*3600+timeReallifeM*60+timeReallifeS
sendcmd("/time set %d" % (timeReallifeSall/86400*24000-6000))



