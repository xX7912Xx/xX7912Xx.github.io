from robot import *
# 作者: 7912, Pomelo.
# 描述: 记录玩家上次下线时间
# 这边是检测领地主人上线时间还是都检测 哦哦哦 明白了
# 这个只是记录玩家下线时间的, 处理还是在领地插件内部进行处理 (因为也许之后其他插件恰好要用这个, 比如给玩家提示: 距离你上次上线已经有 x 时间了)



# PLUGIN TYPE: player leave
# 这里的代码会在玩家下线时执行.
setPlayerData("上次下线时间", playername, str(int(time.time())))



# PLUGIN TYPE: player join
# 这里的代码会在玩家上线时执行.
setPlayerData("上次上线时间", playername, str(int(time.time())))




# 这样应该就可以了.