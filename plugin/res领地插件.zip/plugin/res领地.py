from robot import *
msg = ""
# 作者: 7912, Pomelo.
# 描述: 玩家可在租赁服内圈地.   
# 思路:
#     启动时
#         1. 遍历全部玩家数据, 读取 res.txt 中的领地数据并添加到 resList 列表中.
#         2. 如果玩家超多久时间没上线, 就删除他的领地.
#     玩家添加领地时,
#         1. 检测要创建的领地是否在玩家此时坐标附近. 
#         2. 检测领地范围是否合适. [包括大小限制, 高度限制, 还有不能创建的地方的限制(比如主城之类的地方)] 
#         3. 检测领地是否和其他领地冲突 
#         4. 检测玩家金币是否足够.
#         5. 添加领地到列表并写入文件.
#     玩家删除领地时,
#         1. 按比例返还金币. (比如返还 80%)
#         2. 从列表和文件中删除领地.
#     添加/删除 成员/管理员时,
#         修改列表和文件的数据
#     领地保护: 循环获取 allplayers_pos 中的数据, 然后看这个玩家是否在任意非自己的领地内, 如果在, 就直接kill
#     领地管理员可以开关领地保护.
#     权限:
#         其他人: 若领地保护是打开状态, 则进领地就被kill.
#         成员: 可以进领地, 但不能开关保护.
#         领地管理员: 还可以开关保护, 并且邀请成员 
#         领地主人: 有领地所有权限, 可以删除领地, 设置领地管理员
#     用法:
#         见 player message.
# PLUGIN TYPE: def

# 领地大小限制 
RES_SIZE_MAX_X = 64
RES_SIZE_MAX_Y = 64
RES_SIZE_MAX_Z = 64

# 领地位置限制
RES_MIN_Y = -64
RES_MAX_Y = 320

RES_EXPIRE_TIME = 10 # 领地主人和其所有成员均多久不上线时就删除这个领地. (单位为天, -1为永久保存)
RES_PROTECT_RATE = 0.2 # 每多久执行一次保护 (单位为秒)
RES_PLAYER_MAX_OWN_NUM = 3 # 一名玩家领地数量限制
RES_PRICE_PER_BLOCK = 0.5 # 领地单方块价格 
RES_PRICE_SCOREBOARD = "coin" # 金币计分板名称
RES_DELETE_RETURN_RATE = 0.75 # 删除领地时返还的金币数量百分比
RES_ADMIN_MAX_NUM = 2 # 一个领地的管理员最大数量
RES_MEMBER_MAX_NUM = 10 # 一个领地的成员最大数量

# 不能创建领地的地方
RES_PROTECT_PLACE = [
    {
        "名称": "主城",
        "起点": (-100, -64, -100),
        "终点": (100, 320, 100)
    },
    {
        "名称": "主城2",
        "起点": (1000, -64, 1000),
        "终点": (1010, 320, 1010)
    },
]


resStartEndDict = {}
resList: list["residence"] = []
class residence:
    def __init__(self, name: str, owner: str, admin: list, member: list, protect: bool, cube: Cube, dim: int, tpPoint: Point) -> None:
        self.name = name
        self.owner = owner
        self.admin = admin
        self.member = member
        self.protect = protect
        self.cube = cube
        self.dim = dim
        self.tpPoint = tpPoint
        resList.append(self)

    def writeToDisk(self):
        resDataToSave = { 
            "领地名称": self.name,
            "领地起点": self.cube.startPoint.getCoords(),
            "领地终点": self.cube.endPoint.getCoords(),
            "领地传送位置": self.tpPoint.getCoords(),
            "领地维度": self.dim, # 这个暂时不做, 但放在这里, 之后可以再改成支持不同维度的 
            "领地主人": self.owner,
            "领地管理员": self.admin,
            "领地成员": self.member,
            "保护": True
        }
        resData = json.loads(getPlayerData("residence", "system", "[]"))
        resFound = False
        for i in range(len(resData)):
            if resData[i]["领地名称"] == self.name:
                resFound = True
                resData[i] = resDataToSave
                break
        if not resFound:
            resData.append(resDataToSave)
        setPlayerData("residence", "system", json.dumps(resData, ensure_ascii = False, indent = 4))

    def delete(self):
        resData = json.loads(getPlayerData("residence", "system", "[]"))
        for i in range(len(resData)):
            if resData[i]["领地名称"] == self.name:
                resData.pop(i)
                break
        setPlayerData("residence", "system", json.dumps(resData, ensure_ascii = False, indent = 4))
        resList.remove(self)

    def getPlayerNum(self):
        return (len(self.admin)+len(self.member))


# 领地保护函数.
allplayers_pos = {}
def resProtectRepeat(self):
    while True:
        if exiting:
            return # 如果命令系统正在退出, 就停止保护.
        try:
            for player in allplayers_pos:
                if player == robotname:
                    continue # 排除机器人
                if player in adminhigh:
                    continue # 排除命令系统管理员
                playerPos = allplayers_pos[player]["position"]
                playerPoint = Point(playerPos["x"], playerPos["y"], playerPos["z"])
                for res in resList:
                    if res.protect == False:
                        continue # 排除关闭保护了的领地
                    if (player == res.owner) or (player in res.admin) or (player in res.member):
                        continue # 玩家是领地成员, 跳过
                    if (playerPoint in res.cube):
                        # 这里是保护措施
                        # 向进领地的玩家发出警告.
                        tellrawText(player, "§l§4Warning§r", "§c你不能进入玩家 %s 的领地 %s." % (res.owner, res.name))
                        sendcmd('/tp @a[name="%s"] 0 -10 0' % player)
                        sendcmd('/gamemode s @a[name="%s"]' % player)
                        sendcmd('/kill @a[name="%s"]' % player)
                        # 向领地主人和领地管理员发信息. 
                    
                        if res.owner in allplayers:
                            tellrawText(res.owner, "§l§4Warning§r", "§c玩家 %s 尝试进入你的领地 %s." % (player, res.name))
                        for admin in res.admin:
                            if admin in allplayers:
                                tellrawText(admin, "§l§4Warning§r", "§c玩家 %s 尝试进入你管理的 %s 的领地 %s." % (player, res.owner, res.name))
                        break
        except Exception as err:
            errmsg = "领地保护报错, 信息:\n%s" % (str(err))
            color("§c"+traceback.format_exc(), info = "§c 错误 ")
            log("§c" + errmsg, sendtogamewithERROR = True, info = "§c 错误 ")
        finally:
            time.sleep(RES_PROTECT_RATE)




color("§e正在加载领地.", info = "§e 加载 ")
for place in RES_PROTECT_PLACE:
    residence(place["名称"], "保护区域", [], [], False, Cube(Point(place["起点"]), Point(place["终点"])), 0, Point(place["起点"]))
for res in json.loads(getPlayerData("residence", "system", "[]")):
    residence(res["领地名称"], res["领地主人"], res["领地管理员"], res["领地成员"], res["保护"], Cube(Point(res["领地起点"]), Point(res["领地终点"])), res["领地维度"], Point(res["领地传送位置"]))
color("§a已加载 %d 个领地." % len(resList), info = "§a 成功 ")

# 接下来应该检查领地是否有冲突 (比如服主改配置文件改冲突了)
# 如果有冲突, 就直接不能启动命令系统.
color("§e正在检测领地是否存在冲突.", info = "§e 加载 ")
for i in resList:
    for j in resList:
        if i != j:
            if i.name == j.name:
                raise Exception("领地冲突: %s 和 %s 的领地重名了, 名称都为 %s" % (i.owner, j.owner, i.name))
            if (i.cube & j.cube) != None:
                raise Exception("领地冲突: %s 的领地 %s 和 %s 的领地 %s 有重合的部分" % (i.owner, i.name, j.owner, j.name))

if RES_EXPIRE_TIME != -1:
    color("§e正在检测是否存在玩家很久没上线的领地.", info = "§e 加载 ")
    for res in resList[:]:
        lastOnlineTime = [max(getPlayerData("上次上线时间", res.owner, str(int(time.time()))), getPlayerData("上次下线时间", res.owner, str(int(time.time()))))]
        for player in res.admin:
            lastOnlineTime.append(max(getPlayerData("上次上线时间", player, str(int(time.time()))), getPlayerData("上次下线时间", player, str(int(time.time())))))
        for player in res.member:
            lastOnlineTime.append(max(getPlayerData("上次上线时间", player, str(int(time.time()))), getPlayerData("上次下线时间", player, str(int(time.time())))))
        lastOnlineTime = max(lastOnlineTime)
        if time.time()-lastOnlineTime >= RES_EXPIRE_TIME*86400:
            log("§c玩家 %s 和其领地成员均超过 %d 天未上线, 已删除他的领地 %s." % (res.owner, RES_EXPIRE_TIME, res.name), info = "§c 提示 ")
            res.delete()


# PLUGIN TYPE: init
createThread(name = "领地保护", data = {}, func = resProtectRepeat) # 这是创建一个新线程, 在新线程执行 resProtectRepeat 函数.

# PLUGIN TYPE: player message
if msg == ".help":
    tellrawText(playername, text = ".res §o§7- 查看领地插件帮助§r")
if msg == ".res":
    tellrawText(playername, text = """\
  .res start [Y坐标] §o§7- 设置创建起点为 玩家的XZ坐标和输入的Y坐标. 若不输入Y坐标, 则以玩家当前的Y坐标为准.§r
  .res end [Y坐标] §o§7- 设置创建终点为 玩家的XZ坐标和输入的Y坐标. 若不输入Y坐标, 则以玩家当前的Y坐标为准.§r
  .res price §o§7- 显示即将创建的领地信息.§r
  .res create <领地名称> §o§7- 创建领地.§r
  .res delete <领地名称> §o§7- 删除领地.§r
  .res list §o§7- 列出拥有的领地.§r""")
    tellrawText(playername, text = """\
  .res tpset §o§7- 将领地传送地点设置在你的位置.§r 
  .res tp <领地名称> §o§7- 传送到领地.§r
  .res admin add/del <领地名称> <玩家名称> §o§7- 增删领地管理员. (领地管理员可增删领地成员)§r
  .res member add/del <领地名称> <玩家名称> §o§7- 增删领地成员.§r
  注意: 防御只是玩家进入领地时 kill 玩家, 所以像TNT或玩家在外面挖领地内方块的无法防.""") 
if msg.startswith(".res "):
    # 初始化信息
    if playername not in resStartEndDict:
        resStartEndDict[playername] = {"start": None, "end": None}
    # 检测玩家是否在主世界
    if allplayers_pos[playername]["dimension"] != 0: 
        tellrawText(playername, "§l§4ERROR§r", "§c抱歉, 因为作者的技术原因, 只能在主世界使用 res 插件.")
        raise PluginSkip("这里是跳过这个插件的后面部分, 相当于直接return了")


    # 设置起点和终点
    if msg.startswith(".res start") or msg.startswith(".res end"):
        # 先存变量好了
    
        playerPos = allplayers_pos[playername]["position"] 
        playerPoint = Point(floatPos2intPos(playerPos["x"]), floatPos2intPos(playerPos["y"]), floatPos2intPos(playerPos["z"]))
        if len(msg.split(" ")) == 3:
            try:
                playerPoint.moveto("~", floatPos2intPos(msg.split(" ")[2]), "~")
            except:
                tellrawText(playername, "§l§4ERROR§r", "§cY坐标输入不正确.")
                raise PluginSkip("return")
        
        if playerPoint.Y > RES_MAX_Y:
            tellrawText(playername, "§l§4ERROR§r", "§cY坐标太大了, 不能超过 §l%d§r§c." % RES_MAX_Y)
            raise PluginSkip("return")
        if playerPoint.Y < RES_MIN_Y:
            tellrawText(playername, "§l§4ERROR§r", "§cY坐标太小了, 不能超过 §l%d§r§c." % RES_MIN_Y)
            raise PluginSkip("return")
        # 然后检测这个点是不是已经在已有的领地中了, 就提前提示.
        for res in resList:
            if playerPoint in res.cube:
                tellrawText(playername, "§l§4ERROR§r", "§c设置失败, 此处已有玩家 §l%s§r§c 的领地 §l%s§r§c." % (res.owner, res.name))
                raise PluginSkip("return")
        if msg.startswith(".res start"):
            resStartEndDict[playername]["start"] = playerPoint
            tellrawText(playername, "§l领地§r", text = "成功设置起点 (§l%d§r, §l%d§r, §l%d§r)" % playerPoint.getCoords())
        else: 
            resStartEndDict[playername]["end"] = playerPoint
            tellrawText(playername, "§l领地§r", text = "成功设置终点 (§l%d§r, §l%d§r, §l%d§r)" % playerPoint.getCoords())
            tellrawText(playername, "§l领地§r", text = "可以输入 .res price 查看此时的价格, 也可直接开始创建")


    
    # 查看价格或创建领地
    if msg.startswith(".res create ") or msg == ".res price":
        if not resStartEndDict[playername]["start"]:
            tellrawText(playername, "§l§4ERROR§r", "§c未设置起点.")
            raise PluginSkip("return") 
        if not resStartEndDict[playername]["end"]:
            tellrawText(playername, "§l§4ERROR§r", "§c未设置终点.")
            raise PluginSkip("return")

        # 或许可以先显示信息再判断, 这样玩家也可以更好地判定. 
        playerPos = allplayers_pos[playername]["position"]
        playerPoint = Point(playerPos["x"], playerPos["y"], playerPos["z"])
        try:
            resCube = Cube(resStartEndDict[playername]["start"], resStartEndDict[playername]["end"]) 
        except Exception as err: # 如果报错了, 说明领地长宽高至少有一个为0.
            tellrawText(playername, "§l§4ERROR§r", "§c领地过小.")
            raise PluginSkip("return")
        resVolume = resCube.getVolume()
        resSizeX, resSizeY, resSizeZ = resCube.getSize()
        resPrice = float2int(resVolume*RES_PRICE_PER_BLOCK, way = 3) # 使用 只入法 保留整数. 
        tellrawText(playername, "§l领地§r", text = "\n  领地范围 [(§l%d§r, §l%d§r, §l%d§r), (§l%d§r, §l%d§r, §l%d§r)]\n  领地大小(XYZ): §l%d§rx§l%d§rx§l%d§r\n  领地体积: §l%d§l§r 方块\n  领地价格: §l%d§r 金币." % (resCube.startPoint.X, resCube.startPoint.Y, resCube.startPoint.Z, resCube.endPoint.X, resCube.endPoint.Y, resCube.endPoint.Z, resSizeX, resSizeY, resSizeZ, resVolume, resPrice))
        
        # 接下来检测领地范围是否合适
        if (resSizeX > RES_SIZE_MAX_X) or (resSizeY > RES_SIZE_MAX_Y) or (resSizeZ > RES_SIZE_MAX_Z):
            tellrawText(playername, "§l§4ERROR§r", "§c领地过大, 最大范围为 §l%d§r§cx§l%d§r§cx§l%d§r§c, 请重设起点和终点." % (RES_SIZE_MAX_X, RES_SIZE_MAX_Y, RES_SIZE_MAX_Z))
            raise PluginSkip("return")
        
        # 检测领地是否存在冲突
        for res in resList:
            sameArea = resCube & res.cube
            if sameArea != None:
                tellrawText(playername, "§l§4ERROR§r", "§c圈出的区域与 §l%s§r§c 的领地 §l%s§r§c 冲突, 冲突部分为 [(§l%d§r§c, §l%d§r§c, §l%d§r§c), (§l%d§r§c, §l%d§r§c, §l%d§r§c)]." % (res.owner, res.name, sameArea.startPoint.X, sameArea.startPoint.Y, sameArea.startPoint.Z, sameArea.endPoint.X, sameArea.endPoint.Y, sameArea.endPoint.Z))
                raise PluginSkip("return")

        # 如果是选择查看价格.
        if msg == ".res price":
            tellrawText(playername, "§l领地§r", text = "可以输入 .res create <领地名称> 创建领地, 请确保金币足够.")

        # 如果是选择创建领地
        else:
            # 检测领地数量是否达到上限.
            resNum = 0
            for res in resList:
                if playername == res.owner:
                    resNum += 1
            if resNum >= RES_PLAYER_MAX_OWN_NUM: 
                tellrawText(playername, "§l§4ERROR§r", "§c领地数量已达上线 (§l%d§r§c 个)." % RES_PLAYER_MAX_OWN_NUM)
                raise PluginSkip("return")

            # 检测名称是否合理.
            if len(msg.split(" ")) > 3:
                tellrawText(playername, "§l§4ERROR§r", "§c领地名称不能包含空格.")
                raise PluginSkip("return")
            resName = msg.split(" ")[2]
            if not(2 <= len(resName) <= 8): 
                tellrawText(playername, "§l§4ERROR§r", "§c领地名称长度必须在 2 到 8 之间.")
                raise PluginSkip("return")

            # 然后检测有没有重名的领地
            for res in resList:
                if resName == res.name:
                    tellrawText(playername, "§l§4ERROR§r", "§c名称错误, 已经存在名为 §l%s§r§c 的领地了" % resName)
                    raise PluginSkip("return")
            
            # 接下来检测玩家金币是否足够.
            playerCoinNum = getScore(RES_PRICE_SCOREBOARD, playername)
            if playerCoinNum <= resPrice:
                tellrawText(playername, "§l§4ERROR§r", "§c金币不够, 创建领地需要 §l%d§r§c 金币, 你只有 §l%d§r§c 个." % (resPrice, playerCoinNum))
                raise PluginSkip("return")
            
            # 如果此时玩家在领地范围内, 则将领地传送到的地方设置为玩家当前坐标, 否则设置为领地起点.
            if playerPoint in resCube:
                resTpPoint = playerPoint
            else:
                resTpPoint = resCube.startPoint
            
            
            sendcmd('/scoreboard players remove @a[name="%s"] %s %d' % (playername, RES_PRICE_SCOREBOARD, resPrice)) 
            residence(name = resName, owner = playername, admin = [], member = [], protect = [], cube = resCube, dim = 0, tpPoint = resTpPoint).writeToDisk()
            tellrawText(playername, "§l领地§r", text = "创建成功.")
        

    # 删除领地部分
    if msg.startswith(".res delete "):
        resName = msg.split(" ", 2)[2]
        for res in resList[:]:
            if res.owner == playername and res.name == resName:
                tellrawText(playername, "§l领地§r", text = "正在删除领地 §l%s§r." % resName) 
                returnCoinNum = int(res.cube.getVolume()*RES_PRICE_PER_BLOCK*RES_DELETE_RETURN_RATE)
                res.delete()
                tellrawText(playername, "§l领地§r", text = "删除成功, 已退还 §l%d§r 金币." % returnCoinNum)
                sendcmd('/scoreboard players add @a[name="%s"] %s %d' % (playername, RES_PRICE_SCOREBOARD, returnCoinNum))
                raise PluginSkip("return")
        tellrawText(playername, "§l§4ERROR§r", "§c领地未找到.")
    

    # 列出领地部分.
    if msg == ".res list":
        tellrawText(playername, "§l领地§r", text = "领地列表如下:")
        for index, res in enumerate(resList):
            if (res.owner == playername) or (playername in res.admin) or (playername in res.member):
                resSizeX, resSizeY, resSizeZ = res.cube.getSize()
                resVolume = res.cube.getVolume()
                resPrice = float2int(resVolume*RES_PRICE_PER_BLOCK, way = 3) # 使用 只入法 保留整数.
                returnCoinNum = int(resVolume*RES_PRICE_PER_BLOCK*RES_DELETE_RETURN_RATE) # 使用 舍去小数部分法 保留整数.
                if res.owner == playername:
                    resRole = "§a你是此领地的主人§r"
                if playername in res.admin:
                    resRole = "§b你是此领地的管理员§r"
                if playername in res.member:
                    resRole = "你是此领地的成员"
                resAdmin = ", ".join(res.admin)
                resMember = ", ".join(res.member) 
                tellrawText(playername, text = ("""\
                    %d. %s (%s)
                    领地范围 [(§l%d§r, §l%d§r, §l%d§r), (§l%d§r, §l%d§r, §l%d§r)]
                    领地大小(XYZ): §l%d§rx§l%d§rx§l%d§r
                    领地体积: §l%d§l§r 方块
                    领地购买时价格: §l%d§r 金币.
                    领地删除时退还: §l%d§r 金币.
                    领地主人: §l§a%s§r.
                    领地管理员: §l§b%s§r.
                    领地成员: §l%s§r.
                    """.replace("   ", "")) % (
                        index+1, res.name, resRole,
                        res.cube.startPoint.X, res.cube.startPoint.Y, res.cube.startPoint.Z, res.cube.endPoint.X, res.cube.endPoint.Y, res.cube.endPoint.Z,
                        resSizeX, resSizeY, resSizeZ,
                        resVolume,
                        resPrice,
                        returnCoinNum,
                        res.owner,
                        resAdmin,
                        resMember))
    

    # 设置领地传送的地点. 
    if msg == ".res tpset":
        playerPos = allplayers_pos[playername]["position"]
        playerPoint = Point(playerPos["x"], playerPos["y"], playerPos["z"])
        for res in resList:
            if playerPoint in res.cube:
                if (res.owner == playername) or (playername in res.admin):
                    res.tpPoint = playerPoint
                    res.writeToDisk()

                    # 通知
                    if res.owner in allplayers:
                        tellrawText(res.owner, "§l领地§r", text = "已更新领地 §l%s§r 的传送位置到 (§l%.2f§r, §l%.2f§r, §l%.2f§r)" % (res.name, playerPoint.X, playerPoint.Y, playerPoint.Z))
                    for admin in res.admin:
                        if admin in allplayers:
                            tellrawText(admin, "§l领地§r", text = "已更新领地 §l%s§r 的传送位置到 (§l%.2f§r, §l%.2f§r, §l%.2f§r)" % (res.name, playerPoint.X, playerPoint.Y, playerPoint.Z))
                    raise PluginSkip("return")
                else:
                    tellrawText(playername, "§l§4ERROR§r", "§c你没有权限设置.")
                    raise PluginSkip("return")
        tellrawText(playername, "§l§4ERROR§r", "§c未找到领地.")
    

    # 传送到领地
    if msg.startswith(".res tp "):
        resName = msg.split(" ", 2)[2]
        for res in resList:
            if res.name == resName: 
                if (res.owner == playername) or (playername in res.admin) or (playername in res.member):
                    sendcmd('/tp @a[name="%s"] %.2f %.2f %.2f' % (playername, res.tpPoint.X, res.tpPoint.Y, res.tpPoint.Z))
                    tellrawText(playername, "§l领地§r", text = "传送成功.")
                    raise PluginSkip("return")
                else:
                    tellrawText(playername, "§l§4ERROR§r", "§c你没有权限传送.")
                    raise PluginSkip("return")
        tellrawText(playername, "§l§4ERROR§r", "§c未找到领地.")


    # 增删管理员
    if msg.startswith(".res admin add ") or msg.startswith(".res admin del "):
        if len(msg.split(" ")) != 5:
            tellrawText(playername, "§l§4ERROR§r", "§c参数错误.")
            raise PluginSkip("return")
        resName = msg.split(" ", 4)[3]
        adminName = msg.split(" ", 4)[4]
        for res in resList:
            if res.name == resName:
                if res.owner == playername:
                    # 增加
                    if msg.startswith(".res admin add "):
                        # 要增加的管理员是否就是领地主人
                        if adminName == res.owner:
                            tellrawText(playername, "§l§4ERROR§r", "§c你已经是此领地的主人了, 不能给自己降级.")

                        # 要增加的管理员是否已经是管理员了
                        if adminName in res.admin:
                            tellrawText(playername, "§l§4ERROR§r", "§c他已经是此领地的管理员了.")
                            raise PluginSkip("return")

                        # 领地管理员是否达到上限
                        if len(res.admin) >= RES_ADMIN_MAX_NUM:
                            tellrawText(playername, "§l§4ERROR§r", "§c领地管理员人数达到上线.")
                            raise PluginSkip("return")

                        # 要增加的管理员是否是成员.
                        if adminName in res.member:
                            res.member.remove(adminName)
                            res.admin.append(adminName)
                        # 如果不是成员, 要判断领地人数是否达到上限.
                        else:
                            if res.getPlayerNum() >= RES_MEMBER_MAX_NUM:
                                tellrawText(playername, "§l§4ERROR§r", "§c领地总人数达到上线.")
                                raise PluginSkip("return")
                            else:
                                res.admin.append(adminName)

                        # 写入文件
                        res.writeToDisk()

                        # 通知
                        if res.owner in allplayers:
                            tellrawText(res.owner, "§l领地§r", text = "已授予玩家 §l%s§r 在玩家 §l%s§r 的领地 §l%s§r 的管理员权限" % (adminName, res.owner, res.name))
                        for admin in res.admin:
                            if admin in allplayers:
                                tellrawText(admin, "§l领地§r", text = "已授予玩家 §l%s§r 在玩家 §l%s§r 的领地 §l%s§r 的管理员权限" % (adminName, res.owner, res.name))
                        for member in res.member:
                            if member in allplayers:
                                tellrawText(member, "§l领地§r", text = "已授予玩家 §l%s§r 在玩家 §l%s§r 的领地 §l%s§r 的管理员权限" % (adminName, res.owner, res.name))
                        raise PluginSkip("return")
                    
                    # 删除
                    else:
                        # 要增加的管理员是否在管理员列表.
                        if adminName not in res.admin:
                            tellrawText(playername, "§l§4ERROR§r", "§c他还不是此领地的管理员.")
                            raise PluginSkip("return")
                        
                        res.admin.remove(adminName)

                        # 写入文件
                        res.writeToDisk()

                        # 通知
                        if adminName in allplayers:
                            tellrawText(adminName, "§l领地§r", text = "你在玩家 §l%s§r 的领地 §l%s§r 的管理员权限被移除了" % (res.owner, res.name))
                        if res.owner in allplayers:
                            tellrawText(res.owner, "§l领地§r", text = "已移除玩家 §l%s§r 在玩家 §l%s§r 的领地 §l%s§r 的管理员权限" % (adminName, res.owner, res.name))
                        for admin in res.admin:
                            if admin in allplayers:
                                tellrawText(admin, "§l领地§r", text = "已移除玩家 §l%s§r 在玩家 §l%s§r 的领地 §l%s§r 的管理员权限" % (adminName, res.owner, res.name))
                        for member in res.member:
                            if member in allplayers:
                                tellrawText(member, "§l领地§r", text = "已移除玩家 §l%s§r 在玩家 §l%s§r 的领地 §l%s§r 的管理员权限" % (adminName, res.owner, res.name))
                        raise PluginSkip("return")


                else:
                    tellrawText(playername, "§l§4ERROR§r", "§c你没有权限设置.")
                    raise PluginSkip("return")
        tellrawText(playername, "§l§4ERROR§r", "§c未找到领地.")



    # 增删成员
    if msg.startswith(".res member add ") or msg.startswith(".res member del "):
        if len(msg.split(" ")) != 5:
            tellrawText(playername, "§l§4ERROR§r", "§c参数错误.")
            raise PluginSkip("return")
        resName = msg.split(" ", 4)[3]
        memberName = msg.split(" ", 4)[4]
        for res in resList:
            if res.name == resName:
                if (res.owner == playername) or (playername in res.admin):
                    # 增加
                    if msg.startswith(".res member add "):
                        # 要增加的管理员是否就是领地主人
                        if memberName == res.owner:
                            tellrawText(playername, "§l§4ERROR§r", "§c你已经是此领地的主人了, 不能给自己降级.")
                            raise PluginSkip("return") 

                        # 要增加的成员是否已经是管理员了
                        if memberName in res.admin:
                            tellrawText(playername, "§l§4ERROR§r", "§c他已经是此领地的管理员了.")
                            raise PluginSkip("return")

                        # 要增加的管理员是否已经是成员了.
                        if memberName in res.member:
                            tellrawText(playername, "§l§4ERROR§r", "§c他已经是此领地的成员了.")
                            raise PluginSkip("return")
                        
                        # 判断领地人数是否达到上限.
                        if res.getPlayerNum() >= RES_MEMBER_MAX_NUM:
                            tellrawText(playername, "§l§4ERROR§r", "§c领地总人数达到上线.")
                            raise PluginSkip("return") 
                        else:
                            res.member.append(memberName)

                        # 写入文件
                        res.writeToDisk()

                        # 通知
                        if res.owner in allplayers:
                            tellrawText(res.owner, "§l领地§r", text = "已添加成员 §l%s§r 到玩家 §l%s§r 的领地 §l%s§r 内." % (memberName, res.owner, res.name))
                        for admin in res.admin:
                            if admin in allplayers:
                                tellrawText(admin, "§l领地§r", text = "已添加成员 §l%s§r 到玩家 §l%s§r 的领地 §l%s§r 内." % (memberName, res.owner, res.name))
                        for member in res.member:
                            if member in allplayers:
                                tellrawText(member, "§l领地§r", text = "已添加成员 §l%s§r 到玩家 §l%s§r 的领地 §l%s§r 内." % (memberName, res.owner, res.name))
                        raise PluginSkip("return")
                    
                    # 删除
                    else:
                        # 要删除的成员是否在管理员列表.
                        if memberName in res.admin: 
                            tellrawText(playername, "§l§4ERROR§r", "§c他是领地管理员, 请使用 .res admin del 来删除管理员.")
                            raise PluginSkip("return")
                        
                        # 要删除的成员是否在成员列表.
                        if memberName not in res.member:
                            tellrawText(playername, "§l§4ERROR§r", "§c他还不是此领地的成员.")
                            raise PluginSkip("return")
                        
                        res.member.remove(memberName)

                        # 写入文件
                        res.writeToDisk()

                        # 通知
                        if memberName in allplayers:
                            tellrawText(memberName, "§l领地§r", text = "你已不再是玩家 §l%s§r 的领地 §l%s§r 的成员了." % (res.owner, res.name))
                        if res.owner in allplayers:
                            tellrawText(res.owner, "§l领地§r", text = "玩家 §l%s§r 已不再是玩家 §l%s§r 的领地 §l%s§r 的成员了." % (memberName, res.owner, res.name))
                        for admin in res.admin:
                            if admin in allplayers:
                                tellrawText(admin, "§l领地§r", text = "玩家 §l%s§r 已不再是玩家 §l%s§r 的领地 §l%s§r 的成员了." % (memberName, res.owner, res.name))
                        for member in res.member:
                            if member in allplayers:
                                tellrawText(member, "§l领地§r", text = "玩家 §l%s§r 已不再是玩家 §l%s§r 的领地 §l%s§r 的成员了." % (memberName, res.owner, res.name))
                        raise PluginSkip("return")


                else:
                    tellrawText(playername, "§l§4ERROR§r", "§c你没有权限设置.")
                    raise PluginSkip("return")
        tellrawText(playername, "§l§4ERROR§r", "§c未找到领地.")


