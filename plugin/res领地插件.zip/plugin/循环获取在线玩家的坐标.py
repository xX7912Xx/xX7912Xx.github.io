from robot import *
# 作者: 7912, Pomelo.
# 描述: 循环获取在线玩家的坐标并将坐标存在 allplayers_pos 字典中.



# 这边是为领地插件做的前置插件, 用于一直获取玩家坐标
# PLUGIN TYPE: def
# hi hello 嗯
allplayers_pos = {}
def getPosRepeat(self):
    """循环获取在线玩家坐标, 并将坐标存在 allplayers_pos 字典中的函数"""
    global allplayers_pos
    while True:
        if exiting:
            return # 如果命令系统正在退出, 就停止循环获取坐标.
        try:
            allplayers_pos = getPos("@a") # 获取在线玩家坐标.
        except:
            pass



# PLUGIN TYPE: init
createThread(name = "循环获取在线玩家坐标", data = {}, func = getPosRepeat) # 这是创建一个新线程, 在新线程执行 getPosRepeat 函数.
# 这边应该就可以了. 现在可以到 res领地.py 那边开始做插件.