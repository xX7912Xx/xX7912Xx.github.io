# Author: 7912mail
# Description: 
#     对接 NekoMaid 网页控制租赁服的网站, 只能使用 概览 和 终端 这两个页面, 其他都用不了.
#     应该有很多bug, 我技术太差了
#     NekoMaid 官网: http://maid.neko-craft.com/
#     NekoMaid 可直接访问的链接: http://maid.neko-craft.com/?云服务器公网IP:此插件使用的端口/?此插件连接密码#/NekoMaid/dashboard



# PLUGIN TYPE: def
DCSSDPport = 7913 # 插件使用的端口
DCSSDPpassword = "password" # 此插件连接密码
class InvalidArgumentError(Exception):
    pass
class PasswordError(Exception):
    pass
class ApiNotFoundError(Exception):
    pass
class Success(Exception):
    pass
class NekoMaid(Exception):
    pass
sidList = []
def handleDCSSDP(client_socket, client_address, requestData):
    global sidList
    clientAddress, _ = client_address
    requestTime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    response_start_line = "HTTP/1.1 200 OK\n"
    response_headers = "Access-Control-Allow-Origin: *\nContent-Type: application/json; charset = utf-8\n\n"
    response_body = {"status": "fail", "time": requestTime, "ip": clientAddress, "api": None, "param": None}
    try:
        requestUrl = urllib.parse.unquote(requestData.replace("\r", "").split("\n")[0].split(" ", 1)[1].split(" HTTP/")[0])
        requestType = requestData.replace("\r", "").split("\n")[0].split(" ", 1)[0]
        requestAddress = requestData.replace("\r", "").split("\n")[1].split("Host: ", 1)[1]
        # print("[http] %s 访问了: %s%s" % (clientAddress, requestAddress, requestUrl))
        if len(requestUrl.split("?", 1)) == 1:
            raise ApiNotFoundError()
        requestApi = requestUrl.split("?", 1)[0][1:]
        requestParam = {}
        for i in requestUrl.split("?", 1)[1].split("&"):
            try:
                requestParam[i.split("=", 1)[0]] = i.split("=", 1)[1]
            except:
                pass
        response_body["api"] = requestApi
        response_body["param"] = requestParam
        if "transport" in requestParam:
            if "sid" not in requestParam:
                sid = random.randint(10000000,99999999)
                response_body = '0{"pingInterval":25000,"pingTimeout":20000,"upgrades":["websocket"],"sid":"%d"}' % sid
            else:
                sid = requestParam["sid"]
                try:
                    token = urllib.parse.unquote(eval(requestData.replace("\r", "").split("\n")[-1][2:])["token"])
                except:
                    token = ""
                if token == DCSSDPpassword:
                    print("[http] password is correct, saving sid: %s" % sid)
                    sidList.append(sid)
                elif token:
                    print("[http] password is incorrect: %s, rejecting connection." % token)
                if sid in sidList:
                    response_body = '40{"sid":"%s"}42["globalData",{"onlineMode":true,"pluginVersion":"9.9.9","isPaper":false,"hasWhitelist":false,"maxPlayers":40,"spawnRadius":0,"plugins":{},"canSetMaxPlayers":false,"canSetViewDistance":false,"hasTimings":true,"version":"%s (Netease)","canLoadPlugin":false}]' % (sid, server)
                else:
                    response_body = '40{"sid":"%s"}42["!"]41' % sid
            raise NekoMaid()
        if requestType == "GET":
            if "password" not in requestParam:
                raise PasswordError()
            elif requestParam["password"] != DCSSDPpassword:
                raise PasswordError()
            elif requestApi == "sendcmd":
                if "cmd" not in requestParam:
                    raise InvalidArgumentError("cmd")
                sendcmd(requestParam["cmd"])
                raise Success("command was sent")
            elif requestApi == "execFunc":
                if "func" not in requestParam:
                    raise InvalidArgumentError("func")
                exec("result = %s" % requestParam["func"])
                exec("raise Success(result)")
            else:
                raise ApiNotFoundError()
    except NekoMaid as errmsg:
        pass
    except Success as errmsg:
        response_body["status"] = "success"
        response_body["result"] = str(errmsg)
    except PasswordError as errmsg:
        response_body["status"] = "fail"
        response_body["reason"] = "DCSSDP password is incorret"
    except ApiNotFoundError as errmsg:
        response_body["status"] = "fail"
        response_body["reason"] = "api not found"
    except InvalidArgumentError as errmsg:
        response_body["status"] = "fail"
        response_body["reason"] = "invalid argument: %s" % str(errmsg)
    except Exception as err:
        response_body["status"] = "fatal"
        response_body["reason"] = str(errmsg)
        errmsg = "http处理报错, 信息:\n"+str(err)
        log(errmsg, sendtogamewithERROR = True)
        color("§c"+traceback.format_exc())
    finally:
        response = response_start_line + response_headers + str(response_body)
        client_socket.send(bytes(response, "utf-8"))
        client_socket.close()

def DCSSDP():
    #接收http的api请求.
    print("Starting httpApi thread.")
    global client_socket, client_address, server_socket
    try:
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind(("", DCSSDPport))
        server_socket.listen(1024)
        print("httpApi service started.")
        while True:
            client_socket, client_address = server_socket.accept()
            requestData = client_socket.recv(1024).decode()
            handleDCSSDP(client_socket, client_address, requestData)
            client_socket.close()
    except Exception as err:
        errmsg = "httpApi()方法报错, 信息:\n"+str(err)
        log(errmsg, sendtogamewithERROR = True)






connectionlist = {}
g_code_length = 0
g_header_length = 0
PRINT_FLAG = True
def get_datalength(msg):
    global g_code_length
    global g_header_length
    g_code_length = msg[1] & 127
    if g_code_length == 126:
        g_code_length = struct.unpack('>H', msg[2:4])[0]
        g_header_length = 8
    elif g_code_length == 127:
        g_code_length = struct.unpack('>Q', msg[2:10])[0]
        g_header_length = 14
    else:  
        g_header_length = 6  
    g_code_length = int(g_code_length)
    return g_code_length  


def parse_data(msg):
    global g_code_length
    g_code_length = msg[1] & 127
    if g_code_length == 126:
        g_code_length = struct.unpack('>H', msg[2:4])[0]
        masks = msg[4:8]
        data = msg[8:]
    elif g_code_length == 127:
        g_code_length = struct.unpack('>Q', msg[2:10])[0]
        masks = msg[10:14]
        data = msg[14:]
    else:
        masks = msg[2:6]
        data = msg[6:]
    en_bytes = b""
    cn_bytes = []
    for i, d in enumerate(data):
        nv = chr(d ^ masks[i%4])
        nv_bytes = nv.encode()
        nv_len = len(nv_bytes)
        if nv_len == 1:
            en_bytes += nv_bytes
        else:
            en_bytes += b'%s'
            cn_bytes.append(ord(nv_bytes.decode()))
    if len(cn_bytes) > 2:
        cn_str = ""
        clen = len(cn_bytes)
        count = int(clen / 3)
        for x in range(count):
            i = x * 3
            b = bytes([cn_bytes[i], cn_bytes[i + 1], cn_bytes[i + 2]])
            cn_str += b.decode(errors = "ignore")
        new = en_bytes.replace(b'%s%s%s', b'%s')
        new = new.decode()
        try:
            res = (new % tuple(list(cn_str)))
        except: res = new
    else:
        res = en_bytes.decode()
    return res

def sendMessage(msg, connToSend = None):
    global connectionlist
    send_msg = b""
    send_msg += b"\x81"
    back_str = []
    back_str.append('\x81')
    data_length = len(msg.encode())
    if PRINT_FLAG:
        pass
        # print("Send: %s" % msg)
    if data_length <= 125:
        send_msg += str.encode(chr(data_length))
    elif data_length <= 65535:
        send_msg += struct.pack('b', 126)
        send_msg += struct.pack('>h', data_length)
    elif data_length <= (2^64-1):
        send_msg += struct.pack('b', 127)
        send_msg += struct.pack('>q', data_length)
    else:
        print("Failed to send.")
    send_message = send_msg + msg.encode('utf-8')

    connections = []
    for i in connectionlist.keys():
        connections.append(i)
    for connection in connections:
        if send_message != None and len(send_message) > 0 and ((connToSend is None) or ('connection'+str(connToSend) == connection)):
            try:
                connectionlist[connection].send(send_message)
            except:
                print("Failed to send.")
                del connectionlist[connection]

def NekoMaidMsg(msg, msgIndex, connToSend, isLastFormat = False):
    if isLastFormat:
        msg[-1] = "🍺%s" % str(msg[-1]).replace("'", r'\"')
    msg = str(msg).replace("'", '"').replace("\\\\", '\\').replace('"{', "{").replace('}"', "}").replace("unchanged", "'")
    if msg[-2:] == "}]":
        msg = list(msg)
        msg[-1] = '"'
        msg.append("]")
        msg = ''.join(msg)
    sendMessage("%s%s" % (msgIndex, msg), connToSend)

def deleteconnection(item):
    global connectionlist
    del connectionlist['connection'+item]

def logData(self):
    time.sleep(10)
    while True:
        if datetime.datetime.now().strftime("%M")[1] == "0" and datetime.datetime.now().strftime("%S") == "00":
            try:
                addPlayerData("DCSSDP\\data", "system", {"time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "timeStamp": int(time.time()), "playerNumber": len(allplayers), "entityNumber": len(getTarget("@e")), "tps": tps["10m"]}, "add", "")
            except:
                pass
            finally:
                time.sleep(60)
        time.sleep(0.1)

class WebSocketNekoSDP(threading.Thread):
    def __init__(self,conn,index,name,remote,path="", buffer="", sid = ""):
        threading.Thread.__init__(self)
        self.conn = conn
        self.index = index
        self.name = name
        self.remote = remote
        self.path = path
        self.GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
        if buffer == "":
            buffer = self.conn.recv(1024).decode()
        self.buffer = buffer
        self.sid = sid
        self.buffer_utf8 = b""
        self.length_buffer = 0
        self.disconn = False

    def generate_token(self, WebSocketKey):
        WebSocketKey = WebSocketKey + self.GUID
        Ser_WebSocketKey = hashlib.sha1(WebSocketKey.encode(encoding='utf-8')).digest()
        WebSocketToken = base64.b64encode(Ser_WebSocketKey)
        return WebSocketToken.decode('utf-8')

    def send2toNeko(self, data):
        time.sleep(2)
        data = []
        for i in getPlayerData("DCSSDP\\data", "system").split("\n"):
            if i:
                if "tps" in eval(i):
                    tps_now = eval(i)["tps"]
                else:
                    tps_now = 0
                data.append({"chunks": 0, "entities": eval(i)["entityNumber"], "players": eval(i)["playerNumber"], "time": eval(i)["timeStamp"]*1000, "tps": tps_now})
        if len(data) >= 144:
            for i in range(len(data)-144):
                data.pop(0)
        NekoMaidMsg(["NekoMaid:dashboard:info", data], 42, self.index, True)
        while True:
            if self.disconn:
                break
            NekoMaidMsg(["NekoMaid:dashboard:current", {"behinds": 0, "memory": 0, "mspt": 0, "players": allplayers, "time": int(time.time()*1000), "totalMemory": 0, "tps": tps["5s"]}], 42, self.index, True)
            sendMessage("2", connToSend = self.index)
            time.sleep(5)

    def run(self):
        if PRINT_FLAG:
            print('Socket %s Start!' % self.index)
        global g_code_length
        global g_header_length
        self.handshaken = False
        while True:
            try:
                if self.handshaken == False:
                    if self.buffer.find('\r\n\r\n') != -1:
                        headers = {}
                        header, data = self.buffer.split('\r\n\r\n', 1)
                        for line in header.split("\r\n")[1:]:
                            key, value = line.split(": ", 1)
                            headers[key] = value
                        try:
                            WebSocketKey = headers["Sec-WebSocket-Key"]
                        except KeyError:
                            print("Socket %s Handshaken Failed!" % (self.index))
                            deleteconnection(str(self.index))
                            self.disconn = True
                            self.conn.close()
                            break
                        WebSocketToken = self.generate_token(WebSocketKey)
                        headers["Location"] = ("ws://%s%s" %(headers["Host"], self.path))
                        handshake = "HTTP/1.1 101 Switching Protocols\r\n"\
                                "Connection: Upgrade\r\n"\
                                "Sec-WebSocket-Accept: " + WebSocketToken + "\r\n"\
                                "Upgrade: websocket\r\n\r\n"
                        self.conn.send(handshake.encode(encoding='utf-8'))
                        self.handshaken = True
                        g_code_length = 0
                        time.sleep(0.1)
                        if self.sid in sidList:
                            print("[WebSocket] sid is correct: %s, creating connection." % self.sid)
                            createThread("与NekoMaid网站通信", data = {"conn": self.index}, func = self.send2toNeko)
                        else:
                            print("[WebSocket] sid is incorrect: %s, rejecting connection." % self.sid)
                            deleteconnection(str(self.index))
                            self.disconn = True
                            self.conn.close()
                            break
                    else:
                        print("Socket %s Error!" % (self.index))
                        deleteconnection(str(self.index))
                        self.disconn = True
                        self.conn.close()
                        break
                else:
                    try:
                        mm = self.conn.recv(1024)
                    except:
                        return
                    if g_code_length == 0:
                        try:
                            get_datalength(mm)
                        except:
                            print("Socket %s Logout!" % (self.index))
                            deleteconnection(str(self.index))
                            self.disconn = True
                            self.conn.close()
                            break
                    self.length_buffer += len(mm)
                    self.buffer_utf8 += mm
                    if self.length_buffer - g_header_length < g_code_length:
                        print("error")
                        # continue
                    if True:
                        if not self.buffer_utf8:
                            continue
                        recv_message = parse_data(self.buffer_utf8)
                        if recv_message == "quit":
                            print("Socket %s Logout!" % (self.index))
                            deleteconnection(str(self.index))
                            self.conn.close()
                            break
                        try:
                            msgIndex = recv_message.split("[", 1)[0]
                            if len(msgIndex) == 2:
                                msgIndexToSend = msgIndex
                            else:
                                msgIndexToSend = msgIndex
                                msgIndexToSend = list(msgIndexToSend)
                                msgIndexToSend[1] = str(int(msgIndex[1])+1)
                                msgIndexToSend = ''.join(msgIndexToSend)
                            recv_message = eval(recv_message[len(msgIndex):].replace("null", "None").replace("false", "False").replace("true", "True"))
                        except:
                            msgIndexToSend = 42
                        # print("Recv: %s" % (recv_message))
                        if recv_message == "2probe":
                            sendMessage("3probe", connToSend = self.index)
                            NekoMaidMsg(["NekoMaid:dashboard:current", {"behinds": 0, "memory": 0, "mspt": 0, "players": allplayers, "time": int(time.time()*1000), "totalMemory": 0, "tps": tps["5s"]}], msgIndexToSend, self.index, True)
                        elif recv_message == "5" or recv_message == 3 or recv_message == "":
                            pass
                        elif recv_message[0] == "switchPage":
                            if recv_message[2] == "dashboard":
                                data = []
                                for i in getPlayerData("DCSSDP\\data", "system").split("\n"):
                                    if i:
                                        if "tps" in eval(i):
                                            tps_now = eval(i)["tps"]
                                        else:
                                            tps_now = 0
                                        data.append({"chunks": 0, "entities": eval(i)["entityNumber"], "players": eval(i)["playerNumber"], "time": eval(i)["timeStamp"]*1000, "tps": tps_now})
                                if len(data) >= 144:
                                    for i in range(len(data)-144):
                                        data.pop(0)
                                NekoMaidMsg(["NekoMaid:dashboard:info", data], msgIndexToSend, self.index, True)
                                NekoMaidMsg(["NekoMaid:dashboard:current", {"behinds": 0, "memory": 0, "mspt": 0, "players": allplayers, "time": int(time.time()*1000), "totalMemory": 0, "tps": tps["5s"]}], msgIndexToSend, self.index, True)
                            elif recv_message[2] == "console":
                                data = []
                                with open("serverMsg/%s.txt" % datetime.datetime.now().strftime("%Y-%m-%d"), "r", encoding = "utf-8") as file:
                                    data1 = file.readlines()
                                n = 1653130729159
                                for i in data1:
                                    n += 1000
                                    data.append({"level": "INFO", "logger": "net.minecraft.server.v1_16_R3.DedicatedServer", "msg": "%s§r" % i.replace("\n", "").replace("'", 'unchanged').replace("\\", '\\\\'), "time": n})
                                if len(data) >= 100:
                                    for i in range(len(data)-100):
                                        data.pop(0)
                                NekoMaidMsg(["NekoMaid:console:logs", data], msgIndexToSend, self.index, True)
                        elif recv_message[0].startswith("NekoMaid:") and recv_message[0] != "NekoMaid:":
                            page = recv_message[0].split(":")[1]
                            action = recv_message[0].split(":")[2]
                            if page == "dashboard":
                                if action == "kick":
                                    sendcmd("/kick %s %s" % (recv_message[1], recv_message[2]))
                                    sendcmd("/kick %s" % (recv_message[1]))
                                    # time.sleep(0.5)
                                    # NekoMaidMsg(["NekoMaid:dashboard:current", {"behinds": 0, "memory": 0, "mspt": 0, "players": allplayers, "time": int(time.time()*1000), "totalMemory": 0, "tps": 0}], msgIndexToSend, self.index, True)
                            elif page == "console":
                                if action == "run":
                                    sendcmd(recv_message[1].replace("%s%s", "§"))
                                    sendMessage("%s[true]" % msgIndexToSend, connToSend = self.index)
                        else:
                            pass
            except Exception as err:
                errmsg = "WebSocket处理报错, 信息:\n"+str(err)
                log(errmsg, sendtogamewithERROR = True)
                color("§c"+traceback.format_exc())
                print("Socket %s Logout!" % (self.index))
                deleteconnection(str(self.index))
                self.disconn = True
                self.conn.close()
                break
            finally:
                g_code_length = 0
                self.length_buffer = 0
                self.buffer_utf8 = b""


class WebSocketServerNekoSDP(object):
    def __init__(self):
        self.socket = None
        self.i = 0

    def begin(self, data):
        global connectionlist
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.bind(('0.0.0.0', DCSSDPport))
        self.socket.listen(64)
        while True:
            try:
                connection, address = self.socket.accept()
                buffer = connection.recv(1024).decode()
            except:
                continue
            if "transport=polling" in buffer or "&password=" in buffer:
                handleDCSSDP(connection, address, buffer)
            else:
                try:
                    requestUrl = urllib.parse.unquote(buffer.replace("\r", "").split("\n")[0].split(" ", 1)[1].split(" HTTP/")[0])
                    requestParam = {}
                    for i in requestUrl.split("?", 1)[1].split("&"):
                        try:
                            requestParam[i.split("=", 1)[0]] = i.split("=", 1)[1]
                        except:
                            pass
                    newSocket = WebSocketNekoSDP(connection,self.i,address[0],address, buffer = buffer, sid = requestParam["sid"])
                    #线程启动
                    newSocket.start()
                    #更新连接的集合(hash表的对应关系)-name->sockfd
                    connectionlist['connection'+str(self.i)]=connection
                    self.i += 1
                except:
                    print("[WebSocket] Sid is None")
                    connection.close()



# PLUGIN TYPE: init
WebSocketNekoSDPplugin = WebSocketServerNekoSDP()
createThread("接受NekoMaid网页的连接请求", data = {}, func = WebSocketNekoSDPplugin.begin)
createThread("每10分钟记录一次租赁服信息(NekoSDP插件)", data = {}, func = logData)
