# Author: unknown
Description: unknown



# PLUGIN TYPE: player join
if playername in adminhigh:
    sendcmd("/op %s" % playername)
else:
    sendcmd("/deop %s" % playername)


