# Author: unknown
Description: unknown



# PLUGIN TYPE: repeat 1s
try:
    sendcmd("/title @a actionbar %s:%s" % (timeGameHstr, timeGameMstr))
except:
    pass
finally:
    sendcmd("/time add 0")



