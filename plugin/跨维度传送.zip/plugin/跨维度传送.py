from robot import *
# 作者: 7912
# 描述: 跨维度传送.
#     插件会用一分钟的时间自动在主世界, 地狱, 末地各创建一个常加载区域和一个盔甲架.
#     如果失败, 请重启命令系统.



# PLUGIN TYPE: def
def tp(target,* , x, y, z, dimension):
    if dimension == 0:
        sendcmd("/execute @e[type=armor_stand, name=DotCS_overworld, c=1] ~ ~ ~ /tp %s %s %s %s" % (target, x, y, z))
        return
    if dimension == 1:
        sendcmd("/execute @e[type=armor_stand, name=DotCS_the_nether, c=1] ~ ~ ~ /tp %s %s %s %s" % (target, x, y, z))
        return
    if dimension == 2:
        sendcmd("/execute @e[type=armor_stand, name=DotCS_the_end, c=1] ~ ~ ~ /tp %s %s %s %s" % (target, x, y, z))
        return
    raise ValueError("dimension参数仅可以是0, 1或2.")



# PLUGIN TYPE: init
color("§e正在配置跨维度传送.", info = "§e 加载 ")
robotDim = getPos(robotname)["dimension"]
if robotDim != 0:
    color("§e机器人不在主世界, 正在传到主世界.", info = "§e 加载 ")
    sendcmd("/tp @s @e[type=armor_stand, name=DotCS_overworld]", True)
    countdown(5, "等待世界加载")
    sendcmd("/tp @s 77912 1 77912", True)
    time.sleep(3)
    robotDim = getPos(robotname)["dimension"]
    if getBlock(77912, 0, 77912) != "seaLantern":
        sendcmd("/fill 77904 0 77904 77919 5 77919 sealantern 0 hollow")
    if robotDim == 1:
        if getBlock(77905, 1, 77905) != "portal":
            sendcmd("/setblock 77905 1 77905 portal")
        sendcmd("/tp @s 77905 0 77905")
        while getPos(robotname)["dimension"] != 0:
            pass
    if robotDim == 2:
        if getBlock(77905, 1, 77905) != "end_portal":
            sendcmd("/setblock 77905 1 77905 end_portal")
        sendcmd("/tp @s 77905 0 77905")
        while getPos(robotname)["dimension"] != 0:
            pass
    sendcmd("/tp @s 100000 100000 100000", True)
    color("§a成功将机器人传到主世界.", info = "§a 成功 ")


color("§e检测常加载区块数量.", info = "§e 加载 ")
tickareaList = getTickingAreaList()
tickareaAvaliableNum = 10-len(tickareaList)
for tickareaName in ["DotCS_overworld", "DotCS_the_nether", "DotCS_the_end"]:
    if tickareaName in tickareaList:
        tickareaAvaliableNum += 1
    else:
        countdown(5, "等待世界加载")

if tickareaAvaliableNum < 3:
    color("§c可创建的常加载区块数量不够.", info = "§c 错误 ")
    exitChatbarMenu(reason = "可创建的常加载区块数量不够.")


for dimension in range(0, 3):
    if dimension == 0:
        if "DotCS_overworld" not in tickareaList:
            color("§e主世界常加载不存在, 正在添加.", info = "§e 加载 ")
            sendcmd("/tickingarea add 77904 0 77904 77919 0 77919 DotCS_overworld")
            sendcmd("/tp @s 77912 1 77912", True)
            time.sleep(2)
            if getBlock(77912, 0, 77912) != "seaLantern":
                sendcmd("/fill 77904 0 77904 77919 5 77919 sealantern 0 hollow")
        if not getTarget("@e[type=armor_stand, name=DotCS_overworld]"):
            color("§e主世界盔甲架不存在, 正在生成.", info = "§e 加载 ")
            if getBlock(77912, 0, 77912) != "seaLantern":
                sendcmd("/fill 77904 0 77904 77919 5 77919 sealantern 0 hollow")
            sendcmd("/summon armor_stand DotCS_overworld 77912 1 77912")
            time.sleep(1)
    if dimension == 1:
        if "DotCS_the_nether" not in tickareaList:
            color("§e地狱常加载不存在, 正在添加.", info = "§e 加载 ")
            sendcmd("/tp @s 77912 1 77912", True)
            time.sleep(2)
            if getBlock(77905, 1, 77905) != "portal":
                sendcmd("/setblock 77905 1 77905 portal")
            time.sleep(1)
            sendcmd("/tp @s 77905 0 77905")
            while getPos(robotname)["dimension"] != 1:
                pass
            time.sleep(1)
            time.sleep(1)
            sendcmd("/tickingarea add 77904 0 77904 77919 0 77919 DotCS_the_nether")
            time.sleep(1)
            sendcmd("/tp @s 77912 1 77912", True)
            time.sleep(1)
            if getBlock(77912, 0, 77912) != "seaLantern":
                sendcmd("/fill 77904 0 77904 77919 5 77919 sealantern 0 hollow")
        if not getTarget("@e[type=armor_stand, name=DotCS_the_nether]"):
            color("§e地狱盔甲架不存在, 正在生成.", info = "§e 加载 ")
            if getPos(robotname)["dimension"] == 0:
                sendcmd("/tp @s 77912 1 77912", True)
                time.sleep(2)
                if getBlock(77905, 1, 77905) != "portal":
                    sendcmd("/setblock 77905 1 77905 portal")
                    time.sleep(1)
                sendcmd("/tp @s 77905 0 77905")
                while getPos(robotname)["dimension"] != 1:
                    pass
                time.sleep(1)
            time.sleep(1)
            sendcmd("/tp @s 77912 1 77912", True)
            time.sleep(2)
            if getBlock(77912, 0, 77912) != "seaLantern":
                sendcmd("/fill 77904 0 77904 77919 5 77919 sealantern 0 hollow")
            sendcmd("/summon armor_stand DotCS_the_nether 77912 1 77912")
        if getPos(robotname)["dimension"] == 1:
            sendcmd("/tp @s @e[type=armor_stand, name=DotCS_overworld]", True)
            while getPos(robotname)["dimension"] != 0:
                pass
    time.sleep(1)
    if dimension == 2:
        if "DotCS_the_end" not in tickareaList:
            color("§e末地常加载不存在, 正在添加.", info = "§e 加载 ")
            sendcmd("/tp @s 77912 1 77912", True)
            time.sleep(2)
            if getBlock(77918, 1, 77918) != "end_portal":
                sendcmd("/setblock 77918 1 77918 end_portal")
                time.sleep(1)
            sendcmd("/tp @s 77918 0 77918")
            while getPos(robotname)["dimension"] != 2:
                pass
            time.sleep(1)
            time.sleep(1)
            sendcmd("/tickingarea add 77904 0 77904 77919 0 77919 DotCS_the_end")
            time.sleep(1)
            sendcmd("/tp @s 77912 1 77912", True)
            time.sleep(2)
            if getBlock(77912, 0, 77912) != "seaLantern":
                sendcmd("/fill 77904 0 77904 77919 5 77919 sealantern 0 hollow")
        if not getTarget("@e[type=armor_stand, name=DotCS_the_end]"):
            color("§e末地盔甲架不存在, 正在生成.", info = "§e 加载 ")
            if getPos(robotname)["dimension"] == 0:
                sendcmd("/tp @s 77912 1 77912", True)
                time.sleep(1)
                if getBlock(77918, 1, 77918) != "end_portal":
                    sendcmd("/setblock 77918 1 77918 end_portal")
                time.sleep(1)
            sendcmd("/tp @s 77918 0 77918")
            while getPos(robotname)["dimension"] != 2:
                pass
            time.sleep(1)
        time.sleep(1)
        sendcmd("/tp @s 77912 1 77912", True)
        time.sleep(2)
        if getBlock(77912, 0, 77912) != "seaLantern":
                sendcmd("/fill 77904 0 77904 77919 5 77919 sealantern 0 hollow")
        sendcmd("/summon armor_stand DotCS_the_end 77912 1 77912")
    if getPos(robotname)["dimension"] == 2:
        sendcmd("/tp @s @e[type=armor_stand, name=DotCS_overworld]", True)

color("§a成功配置跨维度传送.", info = "§a 成功 ")