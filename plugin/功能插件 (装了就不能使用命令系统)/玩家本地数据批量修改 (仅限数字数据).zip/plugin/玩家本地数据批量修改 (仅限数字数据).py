# 作者: 7912
# 描述: 修改全部玩家的本地数字数据.



# PLUGIN TYPE: def
from dataclasses import replace


print_Py("\n"*(console.height))
color("§e此插件用于修改全部玩家的 本地数字类型 数据, \n修改完成后请移走此插件, 否则无法使用 DotCS.", info = "§e 提示 ")
color("§e正在获取本地玩家列表.", info = "§e 加载 ")
playerList = os.listdir("player/")
color("§e共有 %d 名玩家." % len(playerList), info = "§e 提示 ")
color("§e正在获取本地数据有哪些名称.", info = "§e 加载 ")
localDataNameList = []
for index, i in enumerate(playerList):
    color("§e[%d/%d] 正在获取玩家: %s" % (index+1, len(playerList), i), info = "§e 加载 ", replace = True, replaceByNext = True)
    for j in os.listdir("player/%s/" % i):
        if (j not in localDataNameList) and (j.endswith(".txt")): localDataNameList.append(j)
color("§e共有 %d 种数据:" % len(localDataNameList), info = "§e 提示 ")
localDataNameDict = {}
for index, i in enumerate(localDataNameList):
    color("§e%d. %s" % (index+1, i), info = "§e 提示 ")
    localDataNameDict[str(index+1)] = i
color("§e请输入要修改的数据序号 (只能修改以数字存储的数据): ", info = "§e 提示 ", end = "")
try:
    localDataNameToEdit = localDataNameDict[input("")]
except:
    color("§c序号未找到.", info = "§c 错误 ")
    time.sleep(1)
    exitChatbarMenu(delay = 7912, reason = "§c修改数据失败.")
color("§e将修改 %d 名玩家 %s 中的数据." % (len(playerList), localDataNameToEdit), info = "§e 提示 ")
color("§e请输入要在此数据上增加多少 (输入负数则为减少): ", info = "§e 提示 ", end = "")
try:
    localDataValueToAdd = float(input())
    if localDataValueToAdd == int(localDataValueToAdd):
        localDataValueToAdd = int(localDataValueToAdd)
except:
    color("§c输入的不是数字.", info = "§c 错误 ")
    time.sleep(1)
    exitChatbarMenu(delay = 7912, reason = "§c修改数据失败.")
color("§e将在3秒后开始修改, 若想取消请关闭DotCS.", info = "§e 信息 ")
localDataNameToEdit = localDataNameToEdit[:-4]
time.sleep(3)
for index, i in enumerate(playerList):
    try:
        color("§e[%d/%d] 正在修改: player/%s/%s.txt" % (index+1, len(playerList), i, localDataNameToEdit), info = "§e 加载 ", replace = True, replaceByNext = True)
        newValue = addPlayerData(localDataNameToEdit, i, localDataValueToAdd, writeNew = "0")
        oldValue = newValue - localDataValueToAdd
        color("§a[%d/%d] %d + %d = %d, 成功修改 player/%s/%s.txt" % (index+1, len(playerList), oldValue, localDataValueToAdd, newValue, i, localDataNameToEdit), info = "§a 成功 ")
    except Exception as err:
        color("§c[%d/%d] 无法修改: player/%s/%s.txt, 开始回滚数据操作." % (index+1, len(playerList), i, localDataNameToEdit), info = "§c 错误 ")
        localDataValueToAdd *= -1
        for jndex, j in enumerate(playerList):
            if jndex >= index: break
            color("§c[%d/%d] 正在回滚: player/%s/%s.txt" % (jndex+1, index, j, localDataNameToEdit), info = "§e 错误 ", replace = True, replaceByNext = True)
            newValue = addPlayerData(localDataNameToEdit, j, localDataValueToAdd, writeNew = "0")
            oldValue = newValue - localDataValueToAdd
            color("§c[%d/%d] %d + %d = %d, 已回滚 player/%s/%s.txt" % (jndex+1, index, oldValue, localDataValueToAdd, newValue, j, localDataNameToEdit), info = "§c 回滚 ")
        color("§a成功回滚数据.", info = "§a 成功 ")
        color("§c----------\n错误位置:\n[%d/%d] 无法修改: player/%s/%s.txt.\n请查看数据是否正常, 然后关闭DotCS.\n----------" % (index+1, len(playerList), i, localDataNameToEdit), info = "§c 错误 ")
        time.sleep(7912)
        exitChatbarMenu(delay = 7912, reason = "§c修改数据失败, 无法修改 player/%s/%s.txt." % (i, localDataNameToEdit))
color("§a成功修改 %d 名玩家的数据.\n请关闭 DotCS, 移除此插件再使用." % len(playerList), info = "§a 成功 ")
time.sleep(7912)
exitChatbarMenu(delay = 7912, reason = "§a修改数据成功.")