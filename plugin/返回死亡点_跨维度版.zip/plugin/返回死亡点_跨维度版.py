from robot import *
from 跨维度传送 import *
# 作者: 7912, Pomelo.
# 描述: 返回死亡点 (跨维度版).



# PLUGIN TYPE: def

LOG_DEATH_TIME = 30 # 记录最小频率 (秒)

if os.path.isfile("./plugin/返回死亡点.py"):
    os.remove("./plugin/返回死亡点.py")
    color("§a已删除旧版 返回死亡点.py, 正在重启", info = "§a 升级 ")
    exitChatbarMenu("已删除旧版返回死亡点.py, 正在重启")

def translateDim(dimension):
    if dimension == 0:
        return "主世界"
    if dimension == 1:
        return "地狱"
    if dimension == 2:
        return "末地" 
    raise ValueError("维度只能是0, 1或2.")

# PLUGIN TYPE: player message
if msg == ".backdeath":
    deathData = json.loads(getPlayerData("death_new", playername, writeNew = "{}"))
    if not deathData:
        tellrawText('@a[name="%s"]' % playername, "§l§4ERROR§r", "§c未找到记录.")
        raise PluginSkip("return")
    tp('@a[name="%s"]' % playername, x = deathData["position"]["x"], y = deathData["position"]["y"], z = deathData["position"]["z"], dimension = deathData["dimension"])
    tellrawText('@a[name="%s"]' % playername, "§l死亡点记录§r", "已传送到上次死亡点: [§l%s§r, (§l%s§r, §l%s§r, §l%s§r)]." % (translateDim(deathData["dimension"]), deathData["position"]["x"], deathData["position"]["y"], deathData["position"]["z"]))
    setPlayerData("death_new", playername, "{}")

# 应该可以了 去看看home？ok

# PLUGIN TYPE: player death
deathTime = int(time.time())
deathData_old = json.loads(getPlayerData("death_new", playername, writeNew = "{}"))
if deathData_old:
    deathTimeDelta = deathTime - deathData_old["time"]
    if deathTimeDelta < LOG_DEATH_TIME:
        tellrawText('@a[name="%s"]' % playername, "§l§4ERROR§r", "§c时间间隔过短, 未保存此次记录. (冷却时间: §l%d§r§cs)" % (LOG_DEATH_TIME - deathTimeDelta))
        raise PluginSkip("return")

deathData = getPos('@a[name="%s"]' % playername)
deathData["time"] = deathTime
setPlayerData("death_new", playername, json.dumps(deathData, ensure_ascii = False, indent = 4))
tellrawText('@a[name="%s"]' % playername, "§l死亡点记录§r", "已记录死亡点: [§l%s§r, (§l%s§r, §l%s§r, §l%s§r)], 输入§l.backdeath§r返回." % (translateDim(deathData["dimension"]), deathData["position"]["x"], deathData["position"]["y"], deathData["position"]["z"]))

