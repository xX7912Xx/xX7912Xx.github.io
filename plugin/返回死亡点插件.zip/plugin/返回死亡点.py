# Author: unknown
from syslog import LOG_INFO
from turtle import onclick


Description: unknown



# PLUGIN TYPE: player message
if msg == ".backdeath":
    deathPos = getPlayerData("death", playername)
    if deathPos == 0:
        tellrawText("@a[name=%s]" % playername, "§l§4ERROR§r", "§c未找到记录")
    else:
        deathPos = deathPos.split("pos: ")[1]
        sendcmd("/tp @a[name=%s] %s" % (playername, deathPos))
        tellrawText("@a[name=%s]" % playername, "§l§6Ritle§aBlock§r", "已传送到上次死亡点: §l%s§r." % deathPos)


# PLUGIN TYPE: player death
deathPos = getPos("@a[name=%s]" % playername)["position"]
deathPosX = deathPos["x"]
deathPosY = deathPos["y"]
deathPosZ = deathPos["z"]
setPlayerData("death", playername, "pos: %s %s %s" % (deathPosX, deathPosY, deathPosZ))
tellrawText("@a[name=%s]" % playername, "§l§6Ritle§aBlock§r", "已记录死亡点: §l%s %s %s§r, 输入§l.backdeath§r返回." % (deathPosX, deathPosY, deathPosZ))

