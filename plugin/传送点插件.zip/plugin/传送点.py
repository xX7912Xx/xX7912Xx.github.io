# Author: unknown
Description: unknown



# PLUGIN TYPE: player message
if msg == ".help" or msg == ".help ":
    sendcmd("/tellraw "+playername+r''' {"rawtext":[{"text":"输入§l.home§r查看传送点插件帮助"}]}''')
if msg[0:5] == ".home":
    if msg == ".home" or msg == ".home ":
        sendcmd("/tellraw "+playername+r""" {"rawtext":[{"text":"<§l§6Ritle§aBlock§r> \n传送点插件  帮助菜单\n输入§l.home list §r查询你创建的传送点\n输入§l.home tp <传送点名称> §r传送至此传送点\n输入§l.home add <传送点名称> §r在你的位置创建传送点\n输入§l.home del <传送点名称> §r删除此传送点"}]}""")
    elif msg == ".home list" or msg == ".home list ":
        homeAll = getPlayerData("home", playername)
        if homeAll == 0:
            tellrawText(playername, "§l§6Ritle§aBlock§r", "传送点为空")
            setPlayerData("home", playername, "")
            homeAll = ""
        elif homeAll == "":
            tellrawText(playername, "§l§6Ritle§aBlock§r", "传送点为空")
        else:
            homeAll = homeAll.replace("\r", "").split("\n")
            homeIndex = 1
            for i in homeAll:
                if i == "":
                    continue
                tellrawText(playername, "§l§6Ritle§aBlock§r", "传送点§l%d§r. 名称: %s, 坐标: %s" % (homeIndex, i.split(", pos: ")[0], i.split(", pos: ")[1]))
                homeIndex += 1
    elif msg[0:9] == ".home tp ":
        homeNameToTp = msg.split(" ", 2)[2]
        homeAll = getPlayerData("home", playername)
        homeFound = False
        if homeAll == 0:
            setPlayerData("home", playername, "")
            homeAll = ""
        homeAll = homeAll.replace("\r", "").split("\n")
        for i in homeAll:
            if i == "":
                continue
            if homeNameToTp == i.split(", pos: ")[0]:
                homeFound = True
                sendcmd("/tp %s %s" % (playername, i.split(", pos: ")[1]))
                tellrawText(playername, "§l§6Ritle§aBlock§r", "成功传送至传送点: %s, 坐标: %s" % (i.split(", pos: ")[0], i.split(", pos: ")[1]))
                break
        if not(homeFound):
            tellrawText(playername, "§l§4ERROR§r", "§c传送点 §l%s§r§c 未找到" % homeNameToTp)
    elif msg[0:10] == ".home add ":
        homeNameToAdd = msg.split(" ", 2)[2]
        homePos = getPos(playername)["position"]
        homePosX, homePosY, homePosZ = int(homePos["x"]), int(homePos["y"]), int(homePos["z"])
        homeAll = getPlayerData("home", playername)
        homeFound = False
        if homeAll == 0:
            setPlayerData("home", playername, "")
            homeAll = ""
        homeAll = homeAll.replace("\r", "").split("\n")
        for i in homeAll:
            if i == "":
                continue
            if homeNameToAdd == i.split(", pos: ")[0]:
                homeFound = True
                tellrawText(playername, "§l§4ERROR§r", "§c重名错误: 你已经有传送点: %s, 坐标: %s 了, 无法再次添加." % (i.split(", pos: ")[0], i.split(", pos: ")[1]))
                break
        if not(homeFound):
            addPlayerData("home", playername, "%s, pos: %d %d %d" % (homeNameToAdd, homePosX, homePosY, homePosZ), dataType = "add")
            tellrawText(playername, "§l§6Ritle§aBlock§r", "成功添加传送点: %s, 坐标: %d %d %d" % (homeNameToAdd, homePosX, homePosY, homePosZ))
    elif msg[0:10] == ".home del ":
        homeNameToDel = msg.split(" ", 2)[2]
        homeAll = getPlayerData("home", playername)
        if homeAll == 0:
            setPlayerData("home", playername, "")
            homeAll = ""
        homeFound = False
        homeAll = homeAll.replace("\r", "").split("\n")
        for i in homeAll:
            if i == "":
                continue
            if homeNameToDel == i.split(", pos: ")[0]:
                homeFound = True
                homeAll.remove(i)
                tellrawText(playername, "§l§6Ritle§aBlock§r", "成功删除传送点: %s, 坐标: %s" % (i.split(", pos: ")[0], i.split(", pos: ")[1]))
                break
        if not(homeFound):
            tellrawText(playername, "§l§4ERROR§r", "§c传送点 §l%s§r§c 未找到" % homeNameToDel)
        if homeFound:
            homeNow = ""
            for i in homeAll:
                if i == "":
                    continue
                homeNow += "%s\n" % i
            setPlayerData("home", playername, homeNow)


