# 作者: 7912, Pomelo.
# 描述: 康威生命游戏.
from ensurepip import version
import os



# PLUGIN TYPE: def
# 复制二维列表
def copy2Dlist(src: list[list]) -> list[list]:
    return [row[:] for row in src]



class LifeGame():
    def __init__(self, status: list[list]) -> None:
        self.length = len(status)
        self.width = len(status[0])
        for line in status:
            if len(line) != self.width: raise ValueError("初始状态不正确")
            for pixel in line:
                if pixel != 0 and pixel != 1: raise ValueError("初始状态不正确")
        self.status = status
        self.status_last = []
        self.step = 0
    
    def getPixel(self, x: int, y: int) -> int:
        if (0 <= x < self.length) and (0 <= y < self.width):
            return self.status[x][y]
        else:
            return 0
    
    def __auth(self) -> None:
        for x in range(self.length):
            for y in range(self.width):
                if x != 0 and x != self.length-1 and y != 0 and y != self.width: continue
                if self.getPixel(x, y) == 1:
                    self.__dict__.clear()
                    raise Exception("碰到边缘了, 请尝试增大区域.")
    
    def process(self, step: int = 1) -> None:
        for _ in range(step):
            self.__auth()
            status = copy2Dlist(self.status)
            status_new = copy2Dlist(self.status)
            for x in range(self.length):
                for y in range(self.width):
                    liveNum = 0
                    for x1 in [x-1, x, x+1]:
                        for y1 in [y-1, y, y+1]:
                            if x == x1 and y == y1: continue
                            liveNum += self.getPixel(x1, y1)
                    if   liveNum == 1: status_new[x][y] = 0
                    elif liveNum == 2: pass
                    elif liveNum == 3: status_new[x][y] = 1
                    else:              status_new[x][y] = 0
            self.status = copy2Dlist(status_new)
            self.status_last = copy2Dlist(status)
            self.step += 1
    
    def __str__(self) -> str:
        string_1 = "┌" + "──"*(self.width-1) + "┐"
        string_2 = "└" + "──"*(self.width-1) + "┘"
        string = ""

        string += string_1
        for line in self.status:
            string += "\n"
            for pixel in line:
                string += "\033[0m  " if pixel == 0 else "\033[0;37;7m  "
        string = string + "\033[0m\n"
        string += string_2
        string += ("\n步数: %d\n" % self.step)
        return string





if __name__ == "__main__":
    try:
        color
    except:
        os.system("cls")

        game1 = LifeGame([
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        ])

        game2 = LifeGame([
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0],
            [0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        ])

        while True:
            print(game2, end = "")
            input()
            game2.process()
