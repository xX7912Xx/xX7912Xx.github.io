from robot import *
from LifeGame import *
from res领地 import RES_PROTECT_PLACE, resList
msg = ""
# 作者: 7912, Pomelo.
# 描述: 租赁服内实现康威生命游戏.
#hi 看到了
#能看到马 ok
# 思路:
#     玩家在地上放置方块, 作为初始状态.
#     输入 .game lg save <名称> <x1> <z1> <x2> <z2> 保存初始状态. (保存完后fill掉区域) 
#     输入 .game lg del <名称> 删除初始状态记录.
#     输入 .game lg start <名称> <步数> 加载初始状态到当前位置并运行.
#     命令系统会自动获取这个区域内的方块, 然后计算下一步的图形, setblock 放置.
#     如果步数到了或者有细胞碰到了边缘, 就停止.
# 或许... 用告示牌确定范围..? 还是输入坐标..? 输入会输入会方便写代码一点? 是的 那就输入
# 需要增加一个保存状态的功能吗..? 这样玩家可以保存那就输入 初始状态?
# 就是用黑白混凝土模拟 加把

# PLUGIN TYPE: def
# 首先创建一个class, 存储数据. (玩家名称, 坐标, LifeGame库的状态)
# 或许... 你来试试..? az 我还是先观摩一下吧 ok 有毒

# 配置
LG_BLOCK_GET_CELL_ALIVE = "concrete.white" # 细胞存活时的方块 [用getBlock()获取到的方块名称]
LG_BLOCK_GET_CELL_DEAD = "concrete.black" # 细胞死亡时的方块 [用getBlock()获取到的方块名称]
LG_BLOCK_SET_CELL_ALIVE = "concrete 15" # 细胞存活时的方块 (用/setblock指令时的方块名称, 可以包括特殊值)
LG_BLOCK_SET_CELL_DEAD = "concrete 0" # 细胞死亡时的方块 (用/setblock指令时的方块名称, 可以包括特殊值)
LG_MAX_STEP = 100 # 最大步数
LG_MAX_BLOCK = 400 # 最大区域大小
LG_MAX_SAVE_NUM = 5 # 最大保存数量
LG_PROCESS_DELAY = 0.25 # 每运行一步后延迟的时间
LG_PROTECT_PLACE = [ # 不能运行生命游戏的地方
    {
        "名称": "主城",
        "起点": (-100, -64, -100),
        "终点": (100, 320, 100)
    },
    {
        "名称": "主城2",
        "起点": (1000, -64, 1000),
        "终点": (1010, 320, 1010)
    },
]
# 如果装了res领地插件, 就用那里面的信息.
if os.path.isfile("plugin/res领地.py"):
    has_res = True
    LG_PROTECT_PLACE = []
else:
    has_res = False


# 检测两个二维数组的不同部分
def xor2Dlist(a, b):
    if len(a) != len(b) or len(a[0]) != len(b[0]):
        return None
    ret = []
    for i in range(len(a)):
        ret.append([])
        for j in range(len(a[0])):
            ret[i].append(a[i][j] ^ b[i][j])
    return ret


# 计算二维数组元素之和
def sum2Dlist(a):
    ret = 0
    for i in a:
        ret += sum(i)
    return ret





LifeGameList: list["LifeGameMC"] = []
class LifeGameMC():
    def __init__(self, playername: str, cube: Cube, LG: LifeGame, step: int, protect = False) -> None:
        self.playername = playername
        self.cube = cube
        self.LG = LG # 问题12: 写成了 LifeGame, 而不是 LG.
        self.step = step
        LifeGameList.append(self)
        if not protect:
            createThread(name = "康威生命游戏", data = {"data": self}, func = self.run)
    
    def run(self, _):
        tellrawText(self.playername, dispname = "§f康威生命游戏§r", text = "创建成功, 正在生成地图.")
        try:
            for x in range(len(self.LG.status)):
                for z in range(len(self.LG.status[0])):
                    sendcmd("/setblock %d %d %d %s" % (self.cube.startPoint.X + x, self.cube.startPoint.Y, self.cube.startPoint.Z + z, LG_BLOCK_SET_CELL_DEAD if self.LG.status[x][z] else LG_BLOCK_SET_CELL_ALIVE))
                    time.sleep(0.01)
                sendcmd("/title %s actionbar §f康威生命游戏§r\n正在生成地图 [%d/%d]" % (self.playername, (x+1)*(z+1), len(self.LG.status)*len(self.LG.status[0])))
            time.sleep(3)
            for _ in range(self.step):
                sendcmd("/title %s actionbar §f康威生命游戏§r\n当前步数: %d\n剩余步数: %d\n活细胞数: %d" % (self.playername, self.LG.step, self.step-self.LG.step, sum2Dlist(self.LG.status)))
                self.LG.process()
                # 应该判定哪些方块被更改了, 这样setblock可以减小租赁服压力
                changedBlock = xor2Dlist(self.LG.status_last, self.LG.status)
                for x in range(len(changedBlock)):
                    for z in range(len(changedBlock[0])):
                        if self.LG.status_last[x][z] != self.LG.status[x][z]:
                            sendcmd("/setblock %s %s %s %s" % (self.cube.startPoint.X + x, self.cube.startPoint.Y, self.cube.startPoint.Z + z, LG_BLOCK_SET_CELL_DEAD if self.LG.status[x][z] else LG_BLOCK_SET_CELL_ALIVE))
                time.sleep(LG_PROCESS_DELAY)
        except Exception as err:
            sendcmd("/title %s actionbar §f康威生命游戏§r\n§c运行出错: %s" % (self.playername, err))
        time.sleep(2)
        sendcmd("/fill %s %s %s %s %s %s air" % (self.cube.startPoint.X, self.cube.startPoint.Y, self.cube.startPoint.Z, self.cube.endPoint.X -1, self.cube.endPoint.Y -1, self.cube.endPoint.Z -1))
        LifeGameList.remove(self)

    def stop(self):
        for thread in threadList:
            if thread.name == "康威生命游戏" and thread.data.data == self:
                thread.stop()
                LifeGameList.remove(self)




for LGprotect in LG_PROTECT_PLACE:
    LifeGameMC("保护区域", Cube(Point(LGprotect["起点"]), Point(LGprotect["终点"])), None, LG_MAX_STEP, True) # 问题1: 创建Cube时忘记用Point了.


# PLUGIN TYPE: init
if has_res:
    LG_PROTECT_PLACE = RES_PROTECT_PLACE


# PLUGIN TYPE: player message
# 我感觉... 我写得很慢, 也许是因为我有些地方还没想好.. 我真的感觉你很厉害了
# 我尽量讲解清楚一点 (其实有些地方我自己也不太明白..)
if msg == ".help":
    tellrawText(playername, text = ".game help §o§7- 查看游戏类插件帮助§r")
if msg == ".game help":
    tellrawText(playername, text = ".game lg help §o§7- 查看康威生命游戏帮助§r")
if msg == ".game lg help":
    tellrawText(playername, text = """\
§f康威生命游戏§r
  说明: 在一片区域用 %s 和 %s 方块摆放初始状态, 然后站在上面保存, 最后运行即可.
  .game lg save <名称> <x1> <z1> <x2> <z2> §o§7- 保存初始状态. (保存成功后会fill掉区域)§r
  .game lg del <名称> §o§7- 删除保存的初始状态§r
  .game lg list §o§7- 列出所有保存的初始状态§r
  .game lg start <名称> <步数 (最大为 %d)> §o§7- 加载初始状态到当前位置并运行.§r""" % (LG_BLOCK_SET_CELL_ALIVE, LG_BLOCK_SET_CELL_DEAD, LG_MAX_STEP))

# 保存初始状态.
if msg.startswith(".game lg save "):
    if len(msg.split(" ")) != 8: # 问题2: 忘记写 len() 了. (包括下面的多处地方)
        tellrawText(playername, dispname = "§4ERROR§r", text = "§c命令格式错误, 应为 §l.game lg save <名称> <x1> <z1> <x2> <z2>§r§c.")
        raise PluginSkip("return")

    # 检测玩家是否在主世界.
    playerPos = getPos(playername)
    if playerPos["dimension"] != 0:
        # 好神奇.. 这两行是自动生成的
        tellrawText(playername, dispname = "§4ERROR§r", text = "§c你只能在主世界运行康威生命游戏.§r")
        raise PluginSkip("return")

    # 设置信息.
    LGstatusName = msg.split(" ")[3]
    x1, z1, x2, z2 = int(msg.split(" ")[4]), int(msg.split(" ")[5]), int(msg.split(" ")[6]), int(msg.split(" ")[7])
    if x1 > x2: x1, x2 = x2, x1
    if z1 > z2: z1, z2 = z2, z1
    y = floatPos2intPos(playerPos["position"]["y"]) -1 # 问题3: Y 不小心大写了. (包括下面的多处地方) # 问题4: 没有用 floatPos2intPos() 转换, 而用了 int(). # 问题5: y坐标忘记减1了.
    LGcube = Cube(Point(x1, y, z1), Point(x2+1, y+1, z2+1)) # 问题9: 立方体的结束坐标忘记+1了(包括下面的一处)

    # 名称长度是否正常.
    if len(LGstatusName) > 8 or len(LGstatusName) < 2:
        tellrawText(playername, dispname = "§4ERROR§r", text = "§c名称长度应该在 §l2~8§r§c 个字符内.§r")
        raise PluginSkip("return")

    # 大小是否超过限制.
    if LGcube.getVolume() > LG_MAX_BLOCK:
        tellrawText(playername, dispname = "§4ERROR§r", text = "§c区域大小不能超过 §l%d§r§c 个方块.§r" % LG_MAX_BLOCK)
        raise PluginSkip("return")

    # 检测是否有重名或超过最大保存数量限制.
    LGstatusList = json.loads(getPlayerData("LifeGameStatus", playername, writeNew = "[]"))
    if len(LGstatusList) >= LG_MAX_SAVE_NUM:
        tellrawText(playername, dispname = "§4ERROR§r", text = "§c你已经保存了 §l%d§r§c 个初始状态, 不能再保存了.§r" % LG_MAX_SAVE_NUM) # 神奇, 他居然知道我的写法和格式
        raise PluginSkip("return")
    for LGstatus in LGstatusList:
        if LGstatus["name"] == LGstatusName:
            tellrawText(playername, dispname = "§4ERROR§r", text = "§c已经有一个名为 §l%s§r§c 的初始状态了.§r" % LGstatusName)
            raise PluginSkip("return")
    LGstatus = {"name": LGstatusName, "status": [[]]}

    # 获取范围内方块并转换为状态, 并检测是否有非细胞的方块.
    tellrawText(playername, dispname = "§f康威生命游戏§r", text = "正在获取 [(§l%d§r, §l%d§r, §l%d§r), (§l%d§r, §l%d§r, §l%d§r)] 的 §l%d§r 个方块." % (x1, y, z1, x2, y, z2, LGcube.getVolume()))
    blockList = getMultiBlock(x1, y, z1, x2, y, z2)
    cellX = 0
    cellZ = 0
    for blockIndex, blockPos in enumerate(blockList):
        # 问题10: blockIndex 加了1.
        blockX, blockY, blockZ = blockPos.split(" ")
        blockX, blockY, blockZ = int(blockX), int(blockY), int(blockZ) # 问题6: 没有用 int() 转换. (包括下面的一处)
        blockName = blockList[blockPos]
        if (blockIndex % (z2-z1+1) == 0) and (blockIndex != 0): # 问题11: 没有加上 blockIndex != 0 的判断.
            cellX += 1
            cellZ = 0
            LGstatus["status"].append([]) # 问题7: 忘记扩展列表长度了, 导致下标越界.
        else:
            cellZ += 1
        # color("%d, %d, %s" % (cellX, cellZ, LGstatus["status"]))
        if blockName == LG_BLOCK_GET_CELL_ALIVE:
            LGstatus["status"][cellX].append(1) # 问题8: 没有用 append() 而是直接用下标赋值, 导致下标越界. (包括下两行)
        elif blockName == LG_BLOCK_GET_CELL_DEAD:
            LGstatus["status"][cellX].append(0)
        else:
            tellrawText(playername, dispname = "§4ERROR§r", text = "§c区域内有非细胞方块 §l%s§r§c, (§l%d§r§c, §l%d§r§c, §l%d§r§c), 请检查后重试.§r" % (blockName, blockX, blockY, blockZ)) # 感觉自动推荐还是比较好用
            raise PluginSkip("return")
        # 等我想一下... 恩
    
    # fill掉区域内的方块.
    sendcmd("/fill %d %d %d %d %d %d air" % (x1, y, z1, x2, y, z2))

    # 保存状态.
    LGstatusList.append(LGstatus)
    setPlayerData("LifeGameStatus", playername, json.dumps(LGstatusList, ensure_ascii = False))
    tellrawText(playername, dispname = "§f康威生命游戏§r", text = "保存成功.")


# 删除初始状态.
if msg.startswith(".game lg del "):
    if len(msg.split(" ")) != 4: # 刚刚好像按错键了
        tellrawText(playername, dispname = "§4ERROR§r", text = "§c命令格式错误, 应为 §l.game lg del <名称>§r§c.")
        raise PluginSkip("return")
    LGstatusName = msg.split(" ")[3]

    # 是否存在这个名称的状态.
    # emm直接帮我写好了, 我检查一下
    # 这个自动推荐的真的很厉害
    LGstatusList = json.loads(getPlayerData("LifeGameStatus", playername, writeNew = "[]"))
    for LGstatus in LGstatusList:
        if LGstatus["name"] == LGstatusName:
            LGstatusList.remove(LGstatus)
            setPlayerData("LifeGameStatus", playername, json.dumps(LGstatusList, ensure_ascii = False))
            tellrawText(playername, dispname = "§f康威生命游戏§r", text = "删除成功.")
            raise PluginSkip("return")
    tellrawText(playername, dispname = "§4ERROR§r", text = "§c不存在名为 §l%s§r§c 的初始状态.§r" % LGstatusName)

# 列出初始状态.
if msg == ".game lg list":
    LGstatusList = json.loads(getPlayerData("LifeGameStatus", playername, writeNew = "[]"))
    if len(LGstatusList) == 0:
        tellrawText(playername, dispname = "§4ERROR§r", text = "§c你还没有保存任何初始状态.§r")
        raise PluginSkip("return")
    tellrawText(playername, dispname = "§f康威生命游戏§r", text = "你保存了 §l%d§r 个初始状态:" % len(LGstatusList))
    for LGindex, LGstatus in enumerate(LGstatusList): # 问题来了, 怎么展示... 总不可能在聊天栏直接发出来吧.. 也放不下 能不能生成地能不能生成地图图案? 那就不显示图案了.
        tellrawText(playername, text = "§l%d§r. %s" % (LGindex+1, LGstatus["name"]))

# 运行游戏.
if msg.startswith(".game lg start "):
    if len(msg.split(" ")) != 5:
        tellrawText(playername, dispname = "§4ERROR§r", text = "§c命令格式错误, 应为 §l.game lg start <名称> <步数 (最大为 %d)>§r§c." % LG_MAX_STEP)
        raise PluginSkip("return")
    
    LGstatusName = msg.split(" ")[3]
    LGstep = int(msg.split(" ")[4])

    # 步数范围是否合适.
    if not (0 <= LGstep <= LG_MAX_STEP):
        tellrawText(playername, dispname = "§4ERROR§r", text = "§c步数应在 §l0~%d§r§c 之间.§r" % LG_MAX_STEP)
        raise PluginSkip("return")
    
    # 玩家是否已经创建过了.
    for i in LifeGameList:
        if i.playername == playername:
            tellrawText(playername, dispname = "§4ERROR§r", text = "§c你已经有一个正在运行的生命游戏了.")
            raise PluginSkip("return")

    # 检测玩家是否在主世界.
    playerPos = getPos(playername)
    if playerPos["dimension"] != 0:
        tellrawText(playername, dispname = "§4ERROR§r", text = "§c你只能在主世界运行康威生命游戏.§r")
        raise PluginSkip("return")
    
    # 是否存在这个名称的状态.
    LGstatusList = json.loads(getPlayerData("LifeGameStatus", playername, writeNew = "[]"))
    for LGstatus in LGstatusList:
        if LGstatus["name"] == LGstatusName:
            LGstatus = LGstatus["status"]
            break
    else: # 嗯..? for循环可以接else吗.. 能把
        tellrawText(playername, dispname = "§4ERROR§r", text = "§c不存在名为 §l%s§r§c 的初始状态.§r" % LGstatusName)
        raise PluginSkip("return")
    # 我试试他会不会自动告诉我for后接else的用法
    # 如果else在for循环后, else会在for循环结束后执行, 且for循环没有被break中断时执行.
    # 学到新用法了
    # ohhh他告诉我了 高级

    # 设置信息.
    x1 = floatPos2intPos(playerPos["position"]["x"])
    y = floatPos2intPos(playerPos["position"]["y"])
    z1 = floatPos2intPos(playerPos["position"]["z"])
    x2 = x1 +len(LGstatus) -1
    z2 = z1 +len(LGstatus[0]) -1
    LGcube = Cube(Point(x1, y, z1), Point(x2+1, y+1, z2+1))

    # 要创建的区域是否发生重叠.
    for i in LifeGameList:
        sameArea = i.cube & LGcube
        if sameArea != None:
            tellrawText(playername, dispname = "§4ERROR§r", text = "§c你要创建的游戏与 §l%s§r§c 的游戏存在冲突, 冲突部分为 [(§l%d§r§c, §l%d§r§c, §l%d§r§c), (§l%d§r§c, §l%d§r§c, §l%d§r§c)]." % (i.playername, sameArea.startPoint.X, sameArea.startPoint.Y, sameArea.startPoint.Z, sameArea.endPoint.X, sameArea.endPoint.Y, sameArea.endPoint.Z))
            raise PluginSkip("return")

    # 如果有领地插件, 检测要创建的区域是否在其他人的领地之内.
    if has_res:
        for res in resList:
            # 跳过自己的领地或自己是成员的领地.
            if (res.owner == playername) or (playername in res.admin) or (playername in res.member):
                continue
            sameArea = res.cube & LGcube
            if (sameArea != None) and (res.dim == 0):
                tellrawText(playername, "§l§4ERROR§r", "§c你要创建的游戏与 §l%s§r§c 的领地 §l%s§r§c 冲突, 冲突部分为 [§l%s§r§c, (§l%d§r§c, §l%d§r§c, §l%d§r§c), (§l%d§r§c, §l%d§r§c, §l%d§r§c)]." % (res.owner, res.name, "主世界", sameArea.startPoint.X, sameArea.startPoint.Y, sameArea.startPoint.Z, sameArea.endPoint.X, sameArea.endPoint.Y, sameArea.endPoint.Z))
                raise PluginSkip("return")
    
    # 检测区域内是否都是空气.
    blockList = getMultiBlock(x1, y, z1, x2, y, z2)
    for blockPos in blockList:
        blockX, blockY, blockZ = blockPos.split(" ")
        blockX, blockY, blockZ = int(blockX), int(blockY), int(blockZ)
        blockName = blockList[blockPos]
        if blockName != "air":
            tellrawText(playername, dispname = "§4ERROR§r", text = "§c你要创建的游戏区域内有方块 §l%s§r§c, (§l%d§r§c, §l%d§r§c, §l%d§r§c), 请清空区域后再运行命令.§r" % (blockName, blockX, blockY, blockZ))
            raise PluginSkip("return")

    # 创建游戏.
    LifeGameMC(playername, LGcube, LifeGame(LGstatus), LGstep)

# 嗯... 可以了..?
# 或许测试一下..? en
