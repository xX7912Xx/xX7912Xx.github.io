# Author: 7912
# Description: 
#     封禁发信息频率过快的玩家.
#     若玩家在 msgSendNunMaxPerTime 秒内发送了 msgSendNumMax 条消息, 则封禁.



# PLUGIN TYPE: def
playerMsgTimeDict = {}
msgSendNunMaxPerTime = 3
msgSendNumMax = 6


# PLUGIN TYPE: player message
if (playername not in adminhigh) and (playername in allplayers):
    msgSendTime = time.time()
    if playername not in playerMsgTimeDict:
        playerMsgTimeDict[playername] = []
    for i in playerMsgTimeDict[playername][:]:
        if i <= msgSendTime - msgSendNunMaxPerTime:
            playerMsgTimeDict[playername].remove(i)
    playerMsgTimeDict[playername].append(msgSendTime)
    if len(playerMsgTimeDict[playername]) >= msgSendNumMax:
        ban(playername, 3600, "发信息过快")
        playerMsgTimeDict[playername] = []


# PLUGIN TYPE: player leave
if playername in playerMsgTimeDict:
    del playerMsgTimeDict[playername]