# Author: 7912
# Description: 
#     When a player places a sign, show the text and the position of the sign in the console.



# PLUGIN TYPE: packet 56
# print(jsonPkt)
if "NBTData" in jsonPkt:
    if "id" in jsonPkt["NBTData"]:
        # 告示牌被放置.
        if jsonPkt["NBTData"]["id"] == "Sign":
            signX, signY, signZ, signText = jsonPkt["NBTData"]["x"], jsonPkt["NBTData"]["y"], jsonPkt["NBTData"]["z"], jsonPkt["NBTData"]["Text"]
            try:
                signPlayerName = getTarget("@a[x=%d, y=%d, z=%d, c=1, r=10]" % (signX, signY, signZ))[0]
            except:
                signPlayerName = "未找到"
            log("告示牌在 (%d, %d, %d) 被放置, 内容: %s, 离它最近的玩家: %s" % (signX, signY, signZ, signText, signPlayerName))
        
        # 活塞推动.
        if jsonPkt["NBTData"]["id"] == "PistonArm":
            pistonX, pistonY, pistonZ, pistonSticky, pistonState, pistonProgress = jsonPkt["NBTData"]["x"], jsonPkt["NBTData"]["y"], jsonPkt["NBTData"]["z"], jsonPkt["NBTData"]["Sticky"], jsonPkt["NBTData"]["State"], jsonPkt["NBTData"]["Progress"]
            if pistonSticky == 1:
                pistonSticky = "粘性"
            else:
                pistonSticky = ""
            if pistonProgress == 0 and pistonState == 1:
                log("%s活塞 (%d, %d, %d) 推出." % (pistonSticky, pistonX, pistonY, pistonZ))
            elif pistonProgress == 1 and pistonState == 3:
                log("%s活塞 (%d, %d, %d) 收回." % (pistonSticky, pistonX, pistonY, pistonZ))
        
        # 潜影盒被放置.
        if jsonPkt["NBTData"]["id"] == "ShulkerBox":
            shulkerboxX, shulkerboxY, shulkerboxZ, shulkerboxItemList = jsonPkt["NBTData"]["x"], jsonPkt["NBTData"]["y"], jsonPkt["NBTData"]["z"], jsonPkt["NBTData"]["Items"]
            try:
                shulkerboxPlayerName = getTarget("@a[x=%d, y=%d, z=%d, c=1, r=10]" % (shulkerboxX, shulkerboxY, shulkerboxZ))[0]
            except:
                shulkerboxPlayerName = "未找到"
            shulkerboxLogStr = "潜影盒在 (%d, %d, %d) 被放置, 离它最近的玩家: %s, 内有物品:" % (shulkerboxX, shulkerboxY, shulkerboxZ, shulkerboxPlayerName)
            for i in shulkerboxItemList:
                shulkerboxItemName, shulkerboxItemSlot, shulkerboxItemCount = i["Name"], i["Slot"], i["Count"]
                shulkerboxLogStr += ("\n栏位 %d: %s * %d" % (shulkerboxItemSlot, shulkerboxItemName, shulkerboxItemCount))
            log(shulkerboxLogStr)