class Point:
    def __init__(self, coords: tuple) -> None:
        self.X, self.Y, self.Z = coords
    
    def getCoords(self) -> tuple:
        return (self.X, self.Y, self.Z)

    def __str__(self) -> str:
        return "a point at (%s, %s, %s)" % self.getCoords()
    
    def __sub__(self, other) -> int | float:
        if type(other) != Point:
            raise TypeError("unsupported operand type(s) for -: 'Point' and '%s'" % other.__class__.__name__)
        return ((self.X-other.X)**2 + (self.Y-other.Y)**2 + (self.Z-other.Z)**2)**0.5


class Cube:
    def __init__(self, start: tuple, end: tuple) -> None:
        self.startX, self.startY, self.startZ = start
        self.endX, self.endY, self.endZ = end
        (self.startX, self.endX) = (self.endX, self.startX) if (self.startX > self.endX) else (self.startX, self.endX)
        (self.startY, self.endY) = (self.endY, self.startY) if (self.startY > self.endY) else (self.startY, self.endY)
        (self.startZ, self.endZ) = (self.endZ, self.startZ) if (self.startZ > self.endZ) else (self.startZ, self.endZ)
        for i in self.getSize():
            if i == 0: raise Exception("It is not a cube.")
    
    def getCoords(self) -> tuple:
        return ((self.startX, self.startY, self.startZ), (self.endX, self.endY, self.endZ))

    def getSize(self) -> tuple:
        return (self.endX-self.startX, self.endY-self.startY, self.endZ-self.startZ)
    
    def getLength(self, axis) -> int | float:
        if axis == "X":
            return self.endX-self.startX
        if axis == "Y":
            return self.endY-self.startY
        if axis == "Z":
            return self.endZ-self.startZ
        raise Exception("You can only get the length of X, Y or Z.")
    
    def getVolume(self) -> int | float:
        return (self.endX-self.startX)*(self.endY-self.startY)*(self.endZ-self.startZ)

    def __str__(self) -> str:
        return "a cube starting at %s, ending at %s" % self.getCoords()

    def  __contains__(cube, point: Point) -> bool:
        if type(point) != Point:
            raise TypeError("unsupported operand type(s) for in: '%s' and 'Cube'" % point.__class__.__name__)
        return True if ((cube.startX <= point.X <= cube.endX) and (cube.startY <= point.Y <= cube.endY) and (cube.startZ <= point.Z <= cube.endZ)) else False

    def __and__(cube1, cube2):
        if type(cube2) != Cube:
            raise TypeError("unsupported operand type(s) for &: 'Cube' and '%s'" % cube2.__class__.__name__)
        minimumBoundingCube = Cube((min(cube1.startX, cube2.startX), min(cube1.startY, cube2.startY), min(cube1.startZ, cube2.startZ)), (max(cube1.endX, cube2.endX), max(cube1.endY, cube2.endY), max(cube1.endZ, cube2.endZ)))
        lengthX = cube1.getLength(axis = "X") + cube2.getLength(axis = "X") - minimumBoundingCube.getLength(axis = "X")
        lengthY = cube1.getLength(axis = "Y") + cube2.getLength(axis = "Y") - minimumBoundingCube.getLength(axis = "Y")
        lengthZ = cube1.getLength(axis = "Z") + cube2.getLength(axis = "Z") - minimumBoundingCube.getLength(axis = "Z")
        if lengthX <= 0 or lengthY <= 0 or lengthZ <= 0:
            return None
        coincideCube = Cube((max(cube1.startX, cube2.startX), max(cube1.startY, cube2.startY), max(cube1.startZ, cube2.startZ)), (min(cube1.endX, cube2.endX), min(cube1.endY, cube2.endY), min(cube1.endZ, cube2.endZ)))        
        return coincideCube



if __name__ == "__main__":
    cube = Cube((1, 2, 3), (4, 5, 6)) # 创建一个立方体
    print(cube) # 输出立方体信息
    print(cube.getSize()) # 输出立方体大小
    print(cube.getVolume()) # 输出立方体体积

    point = Point((2, 3, 4)) # 创建一个点
    print(point) # 输出点的信息
    print(point in cube) # 检测这个点是否在上面的立方体里

    point2 = Point((3, 4, 5)) # 创建另一个点
    print(point2) # 输出这个点的信息
    print(point2 in cube) # 检测这个点是否在上面的立方体里

    print(point2 - point) # 计算两点间的距离
        
    cube2 = Cube((-10, 4.9, 3), (7, 8, 9)) # 创建另一个立方体
    print(cube2) # 输出立方体信息

    print(cube & cube2) # 输出两个立方体的重合部分
