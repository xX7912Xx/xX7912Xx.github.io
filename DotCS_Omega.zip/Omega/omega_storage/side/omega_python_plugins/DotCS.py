# 插件: 开

import importlib
from websocket import WebSocketApp
from omega_side.python3_omega_sync import API
from omega_side.python3_omega_sync import frame as omega
from omega_side.python3_omega_sync.bootstrap import install_lib
from omega_side.python3_omega_sync.protocol import *
import traceback, socket, datetime, time, json, random, sys, urllib, urllib.parse, platform, sqlite3, threading, struct, hashlib, shutil, base64, ctypes, collections, types, itertools, _thread as thread
install_lib("psutil")
install_lib("requests")
install_lib("pymysql")
install_lib("qrcode")
install_lib(lib_name = "websocket", lib_install_name = "websocket-client")
install_lib("brotli")
install_lib(lib_name = "PIL", lib_install_name = "pillow")
install_lib("rich")
install_lib("numpy")
install_lib("mido")
install_lib(lib_name = "Crypto", lib_install_name = "pycryptodome")
import psutil, requests, pymysql, qrcode, websocket, brotli, PIL, rich.console, Crypto.Cipher.DES3
api:API={}

def api_taker(_api:API):
    global api
    api["api"]=_api


omega.add_plugin(api_taker)
time.sleep(1)
api = api["api"]
def nop(*args,**kwargs):
    pass

exec(open("DotCS.py", "r", encoding = "utf-8").read(), locals())