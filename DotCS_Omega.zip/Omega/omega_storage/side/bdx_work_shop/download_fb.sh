#!/bin/sh 

wget https://fastbuilder.pro/downloads/phoenix/phoenixbuilder -O fb \
&& chmod +x fb