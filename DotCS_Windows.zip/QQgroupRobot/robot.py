import socket
import requests, datetime
import random, os
from flask import Flask, request
import logging
import urllib
import urllib.parse
from websocket import create_connection
import time
log = logging.getLogger('werkzeug') #防止监听日志输出.
log.setLevel(logging.ERROR)
port = 5700
connected = False
def log(rev, filename, text, mode = "a", encoding = None, errors = None, output = True, sendgrp = False, sendpri = False):
    if output:
        print(text, end="")
    try:
        file = open(filename, mode, encoding = "utf-8", errors = errors)
        file.write(text)
        if sendgrp:
            if text[-1:] == "\n":
                sendmsg("group", rev["group_id"], text[:-1])
            else:
                sendmsg("group", rev["group_id"], text)
        if sendpri:
            if text[-1:] == "\n":
                sendmsg("private", rev["user_id"], text[:-1])
            else:
                sendmsg("private", rev["user_id"], text)
    except Exception as err:
        print(err)
    finally:
        file.close()
def groupmsg(rev):
    if rev["raw_message"] == "在线玩家" and (rev['group_id'] == 1 or rev['group_id'] == 972226457 or rev['group_id'] == 2): #获取在线玩家
        try:
            result = eval(requests.get("http://127.0.0.1:5556/api?getTarget=@a", timeout=2).text.replace("true", "True").replace("false", "False").replace("null", "None"))
            final = ""
            plsnum = 0
            for i in result:
                final += i + "\n"
                plsnum += 1
            log(rev, "QQmessages\\"+datetime.datetime.now().strftime("%Y-%m-%d.txt"), "当前在线: "+str(plsnum)+"/40\n"+final, encoding = "gbk", errors = "ignore", sendgrp = True)
        except Exception as err: #程序报错了, 返回原因. (自己修下bug)
            try:
                log(rev, "QQmessages\\"+datetime.datetime.now().strftime("%Y-%m-%d.txt"), "获取失败, 原因:\n"+str(err)+"\n", encoding = "gbk", errors = "ignore", sendgrp = True)
            except:
                print(err)
    if "发到服务器 " in rev["raw_message"] and (rev['group_id'] == 1 or rev['group_id'] == 972226457 or rev['group_id'] == 2):
        try:
            msgtosend = rev["raw_message"].split("发到服务器 ")[1]
            cmdtosend = urllib.parse.quote(r'''tellraw @a {"rawtext":[{"text":"<<§l§6Qgroup§r><%s>§r> %s"}]}''' % (rev["sender"]["nickname"], msgtosend))
            result = requests.get("http://127.0.0.1:5556/api?sendcmd=/"+cmdtosend, timeout=2).text.replace("true", "True").replace("false", "False").replace("null", "None")
            if "成功执行" in result:
                log(rev, "QQmessages\\"+datetime.datetime.now().strftime("%Y-%m-%d.txt"), "发送成功.\n", encoding = "gbk", errors = "ignore")
            else:
                log(rev, "QQmessages\\"+datetime.datetime.now().strftime("%Y-%m-%d.txt"), "发送失败, 原因: \n"+result+"\n", encoding = "gbk", errors = "ignore", sendgrp = True)
        except Exception as err: #程序报错了, 返回原因. (自己修下bug)
            try:
                log(rev, "QQmessages\\"+datetime.datetime.now().strftime("%Y-%m-%d.txt"), "发送失败, 原因:\n"+str(err)+"\n", encoding = "gbk", errors = "ignore", sendgrp = True)
            except:
                print(err)
    if "执行指令 /" in rev["raw_message"] and rev["raw_message"][0] != "<" and (rev['group_id'] == 1 or rev['group_id'] == 972226457 or rev['group_id'] == 2):
        try:
            if rev["sender"]["role"] == "member": #使用者非群主或管理员, 无法使用.
                log(rev, "QQmessages\\"+datetime.datetime.now().strftime("%Y-%m-%d.txt"), "执行失败, 原因:\n只有群主或管理员才能使用.\n", encoding = "gbk", errors = "ignore", sendgrp = True)
            else: #使用者是群主或管理员, 执行操作.
                msgtosend = rev["raw_message"].split("执行指令 /")[1]
                cmdtosend = urllib.parse.quote(msgtosend)
                result = requests.get("http://127.0.0.1:5556/api?sendcmd=/"+cmdtosend, timeout=2).text.replace("true", "True").replace("false", "False").replace("null", "None")
                if "成功执行" in result:
                    log(rev, "QQmessages\\"+datetime.datetime.now().strftime("%Y-%m-%d.txt"), "执行成功.\n", encoding = "gbk", errors = "ignore")
                else:
                    log(rev, "QQmessages\\"+datetime.datetime.now().strftime("%Y-%m-%d.txt"), "执行失败, 原因: \n"+result+"\n", encoding = "gbk", errors = "ignore", sendgrp = True)
        except Exception as err: #程序报错了, 返回原因. (自己修下bug)
            try:
                log(rev, "QQmessages\\"+datetime.datetime.now().strftime("%Y-%m-%d.txt"), "执行失败, 原因:\n"+str(err)+"\n", encoding = "gbk", errors = "ignore", sendgrp = True)
            except:
                print(err)
def sendmsg(where, number, message):
    if len(message) >= 200:
        message = message[:200]+"...消息长度大于200, 已省去剩余部分"
    if where == "group":
        requests.get("http://127.0.0.1:"+str(port)+"/send_group_msg?group_id="+str(number)+"&message="+urllib.parse.quote(message), timeout=2).text.replace("true", "True").replace("false", "False").replace("null", "None")
    if where == "private":
        requests.get("http://127.0.0.1:"+str(port)+"/send_private_msg?user_id="+str(number)+"&message="+urllib.parse.quote(message), timeout=2).text.replace("true", "True").replace("false", "False").replace("null", "None")        
app = Flask(__name__) #开始监听端口, 接收消息.
@app.route("/", methods=["POST"])
def rev_msg():
    rev = request.get_json()
    if rev["post_type"] == "notice": #处理通知
        if rev["notice_type"] == "group_recall" and rev["operator_id"] == rev["user_id"]: #群聊消息撤回记录
            recall = eval(requests.get("http://127.0.0.1:"+str(port)+"/get_msg?message_id="+str(rev["message_id"]), timeout=2).text.replace("true", "True"))["data"]
            recall["message"] = recall["message"].replace("&#91;", "[")
            recall["message"] = recall["message"].replace("&#93;", "]")
            recall["message"] = recall["message"].replace("\r", "")
            if rev["user_id"] != rev["self_id"] and (rev["group_id"] == 1 or rev["group_id"] == 2 or rev["group_id"] == 3): #发送撤回的消息
                sendmsg("group", recall["group_id"], "[CQ:at,qq="+str(rev["user_id"])+"] 撤回的消息是: "+recall["message"])
            rev_message = "["+datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")+"] "+"a group message was recalled: "+str(rev["group_id"])+" "+str(rev["user_id"])+" "+recall["message"]+"\n"
            log(rev, "QQmessages\\"+datetime.datetime.now().strftime("%Y-%m-%d.txt"), rev_message, encoding = "gbk", errors = "ignore")
        if rev["notice_type"] == "friend_recall": #私聊消息撤回记录
            recall = eval(requests.get("http://127.0.0.1:"+str(port)+"/get_msg?message_id="+str(rev["message_id"]), timeout=2).text.replace("true", "True").replace("false", "False"))["data"]
            recall["message"] = recall["message"].replace("&#91;", "[")
            recall["message"] = recall["message"].replace("&#93;", "]")
            recall["message"] = recall["message"].replace("\r", "")
            rev_message = "["+datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")+"] "+"a private message was recalled: "+str(rev["user_id"])+" "+recall["message"]+"\n"
            log(rev, "QQmessages\\"+datetime.datetime.now().strftime("%Y-%m-%d.txt"), rev_message, encoding = "gbk", errors = "ignore")
    if rev["post_type"] == "message" or rev["post_type"] == "message_sent": #处理消息
        rev["raw_message"] = rev["raw_message"].replace("&#91;", "[")
        rev["raw_message"] = rev["raw_message"].replace("&#93;", "]")
        rev["raw_message"] = rev["raw_message"].replace("\r", "")
        if rev["message_type"] == "private": #处理私聊消息
            if rev["post_type"] == "message_sent": #处理私聊自发消息
                rev_message = "["+datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")+"] sentprito "+str(rev["target_id"])+" "+rev["raw_message"]+"\n"
            else: #处理私聊收到的消息
                rev_message = "["+datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")+"] "+rev["message_type"]+" "+str(rev["user_id"])+" "+rev["raw_message"]+"\n"
                if "在吗" == rev["raw_message"] or "在?" == rev["raw_message"] or "在吗?" == rev["raw_message"] or "在？" == rev["raw_message"] or "在吗？" == rev["raw_message"]:
                    sendmsg("private", rev["user_id"], "[程序回复] 有事情直接说就行")
            log(rev, "QQmessages\\"+datetime.datetime.now().strftime("%Y-%m-%d.txt"), rev_message, encoding = "gbk", errors = "ignore")
        if rev["message_type"] == "group": #处理群聊消息
            if rev["post_type"] == "message_sent": #处理群聊自发消息
                rev_message = "["+datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")+"] sentgrpto "+str(rev["group_id"])+" "+rev["raw_message"]+"\n"
            else: #处理群聊收到的消息
                rev_message = "["+datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")+"] "+rev["message_type"]+" "+str(rev["group_id"])+" "+str(rev["user_id"])+" "+rev["raw_message"]+"\n"
            log(rev, "QQmessages\\"+datetime.datetime.now().strftime("%Y-%m-%d.txt"), rev_message, encoding = "gbk", errors = "ignore")
            if len(rev["raw_message"]) <= 500:
                groupmsg(rev) #群聊消息额外功能
    return "OK"
app.run(debug=True, host="127.0.0.1", port=5701) #监听配置
