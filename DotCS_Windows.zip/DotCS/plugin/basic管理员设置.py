# Author: unknown
Description: unknown



# PLUGIN TYPE: def
adminxieg = []
adminnorm = []
adminhigh = ["机器人名称", "管理员1", "管理员2", "管理员3"]



